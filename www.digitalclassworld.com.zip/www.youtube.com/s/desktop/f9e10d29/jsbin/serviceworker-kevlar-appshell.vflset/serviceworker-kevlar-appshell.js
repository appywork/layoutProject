/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';
var q, aa = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
    if (a == Array.prototype || a == Object.prototype) return a;
    a[b] = c.value;
    return a
};

function ba(a) {
    a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
    for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c
    }
    throw Error("Cannot find global object");
}
var ca = ba(this);

function da(a, b) {
    if (b) a: {
        var c = ca;a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) break a;
            c = c[e]
        }
        a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && aa(c, a, {
            configurable: !0,
            writable: !0,
            value: b
        })
    }
}

function ea(a) {
    function b(d) {
        return a.next(d)
    }

    function c(d) {
        return a.throw(d)
    }
    return new Promise(function(d, e) {
        function f(g) {
            g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e)
        }
        f(a.next())
    })
}

function r(a) {
    return ea(a())
}
da("Object.entries", function(a) {
    return a ? a : function(b) {
        var c = [],
            d;
        for (d in b) Object.prototype.hasOwnProperty.call(b, d) && c.push([d, b[d]]);
        return c
    }
});

function fa(a, b) {
    a instanceof String && (a += "");
    var c = 0,
        d = !1,
        e = {
            next: function() {
                if (!d && c < a.length) {
                    var f = c++;
                    return {
                        value: b(f, a[f]),
                        done: !1
                    }
                }
                d = !0;
                return {
                    done: !0,
                    value: void 0
                }
            }
        };
    e[Symbol.iterator] = function() {
        return e
    };
    return e
}
da("Array.prototype.values", function(a) {
    return a ? a : function() {
        return fa(this, function(b, c) {
            return c
        })
    }
});
da("Array.prototype.includes", function(a) {
    return a ? a : function(b, c) {
        var d = this;
        d instanceof String && (d = String(d));
        var e = d.length;
        c = c || 0;
        for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0
        }
        return !1
    }
});
da("Object.values", function(a) {
    return a ? a : function(b) {
        var c = [],
            d;
        for (d in b) Object.prototype.hasOwnProperty.call(b, d) && c.push(b[d]);
        return c
    }
});
da("String.prototype.matchAll", function(a) {
    return a ? a : function(b) {
        if (b instanceof RegExp && !b.global) throw new TypeError("RegExp passed into String.prototype.matchAll() must have global tag.");
        var c = new RegExp(b, b instanceof RegExp ? void 0 : "g"),
            d = this,
            e = !1,
            f = {
                next: function() {
                    if (e) return {
                        value: void 0,
                        done: !0
                    };
                    var g = c.exec(d);
                    if (!g) return e = !0, {
                        value: void 0,
                        done: !0
                    };
                    "" === g[0] && (c.lastIndex += 1);
                    return {
                        value: g,
                        done: !1
                    }
                }
            };
        f[Symbol.iterator] = function() {
            return f
        };
        return f
    }
});
da("Promise.prototype.finally", function(a) {
    return a ? a : function(b) {
        return this.then(function(c) {
            return Promise.resolve(b()).then(function() {
                return c
            })
        }, function(c) {
            return Promise.resolve(b()).then(function() {
                throw c;
            })
        })
    }
});
var t = this || self;

function v(a, b) {
    a = a.split(".");
    b = b || t;
    for (var c = 0; c < a.length; c++)
        if (b = b[a[c]], null == b) return null;
    return b
}

function ha() {}

function ia(a, b, c) {
    return a.call.apply(a.bind, arguments)
}

function ja(a, b, c) {
    if (!a) throw Error();
    if (2 < arguments.length) {
        var d = Array.prototype.slice.call(arguments, 2);
        return function() {
            var e = Array.prototype.slice.call(arguments);
            Array.prototype.unshift.apply(e, d);
            return a.apply(b, e)
        }
    }
    return function() {
        return a.apply(b, arguments)
    }
}

function la(a, b, c) {
    Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? la = ia : la = ja;
    return la.apply(null, arguments)
}

function w(a, b) {
    a = a.split(".");
    var c = t;
    a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
    for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
}

function ma(a, b) {
    function c() {}
    c.prototype = b.prototype;
    a.Ea = b.prototype;
    a.prototype = new c;
    a.prototype.constructor = a;
    a.mb = function(d, e, f) {
        for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g)
    }
};

function na(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, na);
    else {
        const c = Error().stack;
        c && (this.stack = c)
    }
    a && (this.message = String(a));
    void 0 !== b && (this.qa = b)
}
ma(na, Error);
na.prototype.name = "CustomError";

function oa(a, b) {
    Array.prototype.forEach.call(a, b, void 0)
}

function pa(a, b) {
    return Array.prototype.map.call(a, b, void 0)
}

function qa(a, b) {
    for (let d = 1; d < arguments.length; d++) {
        const e = arguments[d];
        var c = typeof e;
        c = "object" != c ? c : e ? Array.isArray(e) ? "array" : c : "null";
        if ("array" == c || "object" == c && "number" == typeof e.length) {
            c = a.length || 0;
            const f = e.length || 0;
            a.length = c + f;
            for (let g = 0; g < f; g++) a[c + g] = e[g]
        } else a.push(e)
    }
};

function ra(a) {
    for (const b in a) return !1;
    return !0
}

function sa(a) {
    if (!a || "object" !== typeof a) return a;
    if ("function" === typeof a.clone) return a.clone();
    if ("undefined" !== typeof Map && a instanceof Map) return new Map(a);
    if ("undefined" !== typeof Set && a instanceof Set) return new Set(a);
    const b = Array.isArray(a) ? [] : "function" !== typeof ArrayBuffer || "function" !== typeof ArrayBuffer.isView || !ArrayBuffer.isView(a) || a instanceof DataView ? {} : new a.constructor(a.length);
    for (const c in a) b[c] = sa(a[c]);
    return b
}
const ta = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

function ua(a, b) {
    let c, d;
    for (let e = 1; e < arguments.length; e++) {
        d = arguments[e];
        for (c in d) a[c] = d[c];
        for (let f = 0; f < ta.length; f++) c = ta[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
    }
};

function va() {}

function wa(a) {
    return new va(xa, a)
}
var xa = {};
wa("");
var ya = String.prototype.trim ? function(a) {
    return a.trim()
} : function(a) {
    return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
};

function za() {
    var a = t.navigator;
    return a && (a = a.userAgent) ? a : ""
}

function y(a) {
    return -1 != za().indexOf(a)
};

function Aa() {
    return (y("Chrome") || y("CriOS")) && !y("Edge") || y("Silk")
};
var z = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

function Ba(a) {
    return a ? decodeURI(a) : a
}

function Ca(a, b, c) {
    if (Array.isArray(b))
        for (var d = 0; d < b.length; d++) Ca(a, String(b[d]), c);
    else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
}

function Da(a) {
    var b = [],
        c;
    for (c in a) Ca(c, a[c], b);
    return b.join("&")
};

function Ea(a, b) {
    return Error(`Invalid wire type: ${a} (at position ${b})`)
}

function Fa() {
    return Error("Failed to read varint, encoding is invalid.")
};

function Ga(a, b) {
    b = String.fromCharCode.apply(null, b);
    return null == a ? b : a + b
}
let Ha;
const Ia = "undefined" !== typeof TextDecoder;
!y("Android") || Aa();
Aa();
var Ja = y("Safari") && !(Aa() || y("Coast") || y("Opera") || y("Edge") || y("Edg/") || y("OPR") || y("Firefox") || y("FxiOS") || y("Silk") || y("Android")) && !(y("iPhone") && !y("iPod") && !y("iPad") || y("iPad") || y("iPod"));
var Ka = {},
    La = null;

function Ma(a, b) {
    void 0 === b && (b = 0);
    Na();
    b = Ka[b];
    const c = Array(Math.floor(a.length / 3)),
        d = b[64] || "";
    let e = 0,
        f = 0;
    for (; e < a.length - 2; e += 3) {
        var g = a[e],
            h = a[e + 1],
            k = a[e + 2],
            l = b[g >> 2];
        g = b[(g & 3) << 4 | h >> 4];
        h = b[(h & 15) << 2 | k >> 6];
        k = b[k & 63];
        c[f++] = "" + l + g + h + k
    }
    l = 0;
    k = d;
    switch (a.length - e) {
        case 2:
            l = a[e + 1], k = b[(l & 15) << 2] || d;
        case 1:
            a = a[e], c[f] = "" + b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
    }
    return c.join("")
}

function Oa(a) {
    var b = a.length,
        c = 3 * b / 4;
    c % 3 ? c = Math.floor(c) : -1 != "=.".indexOf(a[b - 1]) && (c = -1 != "=.".indexOf(a[b - 2]) ? c - 2 : c - 1);
    var d = new Uint8Array(c),
        e = 0;
    Pa(a, function(f) {
        d[e++] = f
    });
    return e !== c ? d.subarray(0, e) : d
}

function Pa(a, b) {
    function c(k) {
        for (; d < a.length;) {
            var l = a.charAt(d++),
                m = La[l];
            if (null != m) return m;
            if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
        }
        return k
    }
    Na();
    for (var d = 0;;) {
        var e = c(-1),
            f = c(0),
            g = c(64),
            h = c(64);
        if (64 === h && -1 === e) break;
        b(e << 2 | f >> 4);
        64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
    }
}

function Na() {
    if (!La) {
        La = {};
        for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
            var d = a.concat(b[c].split(""));
            Ka[c] = d;
            for (var e = 0; e < d.length; e++) {
                var f = d[e];
                void 0 === La[f] && (La[f] = e)
            }
        }
    }
};
var Qa = "function" === typeof Uint8Array;

function Ra(a) {
    return Qa && null != a && a instanceof Uint8Array
}
let Sa;
var Ta = class {
    constructor(a) {
        this.h = a;
        if (null !== a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
    }
    isEmpty() {
        return null == this.h
    }
};
const Ua = "function" === typeof Uint8Array.prototype.slice;

function Va(a, b) {
    if (a.constructor === Uint8Array) return a;
    if (a.constructor === ArrayBuffer) return new Uint8Array(a);
    if (a.constructor === Array) return new Uint8Array(a);
    if (a.constructor === String) return Oa(a);
    if (a.constructor === Ta) {
        if (!b && (b = a.h) && b.constructor === Uint8Array) return b;
        if (a.isEmpty()) a = Sa || (Sa = new Uint8Array(0));
        else {
            b = Uint8Array;
            var c = a.h;
            c = null == c || Ra(c) ? c : "string" === typeof c ? Oa(c) : null;
            a = new b(a.h = c)
        }
        return a
    }
    if (a instanceof Uint8Array) return new Uint8Array(a.buffer, a.byteOffset, a.byteLength);
    throw Error("Type not convertible to a Uint8Array, expected a Uint8Array, an ArrayBuffer, a base64 encoded string, or Array of numbers");
};

function Wa(a, b) {
    a.j = Va(b, a.J);
    a.l = 0;
    a.i = a.j.length;
    a.h = a.l
}

function Xa(a) {
    if (a.h > a.i) throw Error(`Tried to read past the end of the data ${a.h} > ${a.i}`);
}

function Ya(a) {
    const b = a.j;
    let c = b[a.h + 0],
        d = c & 127;
    if (128 > c) return a.h += 1, Xa(a), d;
    c = b[a.h + 1];
    d |= (c & 127) << 7;
    if (128 > c) return a.h += 2, Xa(a), d;
    c = b[a.h + 2];
    d |= (c & 127) << 14;
    if (128 > c) return a.h += 3, Xa(a), d;
    c = b[a.h + 3];
    d |= (c & 127) << 21;
    if (128 > c) return a.h += 4, Xa(a), d;
    c = b[a.h + 4];
    d |= (c & 15) << 28;
    if (128 > c) return a.h += 5, Xa(a), d >>> 0;
    a.h += 5;
    if (128 <= b[a.h++] && 128 <= b[a.h++] && 128 <= b[a.h++] && 128 <= b[a.h++] && 128 <= b[a.h++]) throw Fa();
    Xa(a);
    return d
}
var Za = class {
        constructor(a, {
            J: b = !1
        } = {}) {
            this.j = null;
            this.h = this.i = this.l = 0;
            this.J = b;
            a && Wa(this, a)
        }
        clear() {
            this.j = null;
            this.h = this.i = this.l = 0;
            this.J = !1
        }
        reset() {
            this.h = this.l
        }
        advance(a) {
            this.h += a;
            Xa(this)
        }
    },
    $a = [];

function ab(a) {
    var b = a.h;
    if (b.h == b.i) return !1;
    a.l = a.h.h;
    var c = Ya(a.h);
    b = c >>> 3;
    c &= 7;
    if (!(0 <= c && 5 >= c)) throw Ea(c, a.l);
    if (1 > b) throw Error(`Invalid field number: ${b} (at position ${a.l})`);
    a.j = b;
    a.i = c;
    return !0
}

function bb(a) {
    switch (a.i) {
        case 0:
            if (0 != a.i) bb(a);
            else a: {
                a = a.h;
                var b = a.h;
                for (let c = 0; 10 > c; c++) {
                    if (0 === (a.j[b] & 128)) {
                        a.h = b + 1;
                        Xa(a);
                        break a
                    }
                    b++
                }
                throw Fa();
            }
            break;
        case 1:
            a.h.advance(8);
            break;
        case 2:
            2 != a.i ? bb(a) : (b = Ya(a.h), a.h.advance(b));
            break;
        case 5:
            a.h.advance(4);
            break;
        case 3:
            b = a.j;
            do {
                if (!ab(a)) throw Error("Unmatched start-group tag: stream EOF");
                if (4 == a.i) {
                    if (a.j != b) throw Error("Unmatched end-group tag");
                    break
                }
                bb(a)
            } while (1);
            break;
        default:
            throw Ea(a.i, a.l);
    }
}
var cb = class {
        constructor(a) {
            var {
                J: b = !1,
                ga: c = !1
            } = {};
            this.m = {
                J: b
            };
            this.ga = c;
            var d = this.m;
            if ($a.length) {
                const e = $a.pop();
                d && (e.J = d.J);
                a && Wa(e, a);
                a = e
            } else a = new Za(a, d);
            this.h = a;
            this.l = this.h.h;
            this.i = this.j = -1
        }
        reset() {
            this.h.reset();
            this.l = this.h.h;
            this.i = this.j = -1
        }
        advance(a) {
            this.h.advance(a)
        }
    },
    db = [];
const eb = "function" === typeof Symbol && "symbol" === typeof Symbol() ? Symbol(void 0) : void 0;

function fb(a) {
    if (Array.isArray(a)) {
        let b;
        eb ? b = a[eb] : b = a.h;
        a = !!((null == b ? 0 : b) & 1)
    } else a = !1;
    return a
}

function gb(a) {
    Object.isFrozen(a) || (eb ? a[eb] |= 1 : void 0 !== a.h ? a.h |= 1 : Object.defineProperties(a, {
        h: {
            value: 1,
            configurable: !0,
            writable: !0,
            enumerable: !1
        }
    }));
    return a
};

function hb(a) {
    return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
}
let ib;
var jb = Object.freeze(gb([])),
    kb = "undefined" != typeof Symbol && "undefined" != typeof Symbol.hasInstance;

function A(a, b, c = !1) {
    return -1 === b ? null : b >= a.l ? a.i ? a.i[b] : void 0 : c && a.i && (c = a.i[b], null != c) ? c : a.u[b + a.j]
}

function B(a, b, c, d = !1) {
    b < a.l && !d ? a.u[b + a.j] = c : (a.i || (a.i = a.u[a.l + a.j] = {}))[b] = c;
    return a
}

function lb(a, b, c = !1) {
    let d = A(a, b, c);
    null == d && (d = jb);
    d === jb && (d = gb(d.slice()), B(a, b, d, c));
    return d
}

function mb(a, b, c, d) {
    (c = nb(a, c)) && c !== b && null != d && (a.h && c in a.h && (a.h[c] = void 0), B(a, c, void 0));
    return B(a, b, d)
}

function nb(a, b) {
    let c = 0;
    for (let d = 0; d < b.length; d++) {
        const e = b[d];
        null != A(a, e) && (0 !== c && B(a, c, void 0, !1), c = e)
    }
    return c
}

function ob(a, b, c, d, e = !1) {
    if (-1 === c) return null;
    a.h || (a.h = {});
    const f = a.h[c];
    if (f) return f;
    e = A(a, c, e);
    if (null == e && !d) return f;
    b = new b(e);
    return a.h[c] = b
}

function pb(a, b, c, d = !1) {
    a.h || (a.h = {});
    let e = a.h[c];
    if (!e) {
        d = lb(a, c, d);
        e = [];
        for (let f = 0; f < d.length; f++) e[f] = new b(d[f]);
        a.h[c] = e
    }
    return e
}

function C(a, b, c, d = !1) {
    a.h || (a.h = {});
    let e = c ? c.u : c;
    a.h[b] = c;
    return B(a, b, e, d)
}

function qb(a, b, c) {
    var d = rb;
    a.h || (a.h = {});
    let e = c ? c.u : c;
    a.h[b] = c;
    mb(a, b, d, e)
}

function sb(a, b, c, d, e) {
    const f = pb(a, c, b, !1);
    c = d ? d : new c;
    a = lb(a, b);
    void 0 != e ? (f.splice(e, 0, c), a.splice(e, 0, c.u)) : (f.push(c), a.push(c.u));
    return c
};
class tb {
    constructor(a, b, c, d) {
        var e = ub;
        this.i = a;
        this.fieldName = b;
        this.h = c;
        this.isRepeated = d;
        this.j = e
    }
};

function vb(a) {
    switch (typeof a) {
        case "number":
            return isFinite(a) ? a : String(a);
        case "object":
            if (a && !Array.isArray(a)) {
                if (Ra(a)) return Ma(a);
                if (a instanceof Ta) {
                    if (a.isEmpty()) a = "";
                    else {
                        var b = a.h;
                        b = null == b || "string" === typeof b ? b : Qa && b instanceof Uint8Array ? Ma(b) : null;
                        a = a.h = b
                    }
                    return a
                }
            }
    }
    return a
};

function wb(a, b = xb) {
    return yb(a, b)
}

function zb(a, b) {
    if (null != a) {
        if (Array.isArray(a)) a = yb(a, b);
        else if (hb(a)) {
            const c = {};
            for (let d in a) c[d] = zb(a[d], b);
            a = c
        } else a = b(a);
        return a
    }
}

function yb(a, b) {
    const c = a.slice();
    for (let d = 0; d < c.length; d++) c[d] = zb(c[d], b);
    fb(a) && gb(c);
    return c
}

function Ab(a) {
    if (a && "object" == typeof a && a.toJSON) return a.toJSON();
    a = vb(a);
    return Array.isArray(a) ? wb(a, Ab) : a
}

function xb(a) {
    return Ra(a) ? new Uint8Array(a) : a
};
let Bb;

function Cb(a, b, c) {
    var d = Bb;
    Bb = null;
    a || (a = d);
    d = this.constructor.ma;
    a || (a = d ? [d] : []);
    this.j = (d ? 0 : -1) - (this.constructor.tb || 0);
    this.h = void 0;
    this.u = a;
    a: {
        d = this.u.length;a = d - 1;
        if (d && (d = this.u[a], hb(d))) {
            this.l = a - this.j;
            this.i = d;
            break a
        }
        void 0 !== b && -1 < b ? (this.l = Math.max(b, a + 1 - this.j), this.i = void 0) : this.l = Number.MAX_VALUE
    }
    if (c)
        for (b = 0; b < c.length; b++)
            if (a = c[b], a < this.l) a += this.j, (d = this.u[a]) ? Array.isArray(d) && gb(d) : this.u[a] = jb;
            else {
                d = this.i || (this.i = this.u[this.l + this.j] = {});
                let e = d[a];
                e ? Array.isArray(e) &&
                    gb(e) : d[a] = jb
            }
}
Cb.prototype.toJSON = function() {
    const a = Db(this.u);
    return ib ? a : wb(a, Ab)
};

function Eb(a) {
    ib = !0;
    try {
        return JSON.stringify(a.toJSON(), Fb)
    } finally {
        ib = !1
    }
}
Cb.prototype.clone = function() {
    var a = this.constructor,
        b = wb(this.u);
    Bb = b;
    a = new a(b);
    Bb = null;
    Gb(a, this);
    return a
};

function Fb(a, b) {
    return vb(b)
}

function Db(a) {
    let b, c = a.length,
        d = !1;
    for (let g = a.length; g--;) {
        let h = a[g];
        if (Array.isArray(h)) {
            var e = h;
            Array.isArray(h) && fb(h) && !h.length ? h = null : h = Db(h);
            h != e && (d = !0)
        } else if (g === a.length - 1 && hb(h)) {
            a: {
                var f = h;e = {};
                let k = !1;
                for (let l in f) {
                    let m = f[l];
                    if (Array.isArray(m)) {
                        let p = m;
                        Array.isArray(m) && fb(m) && !m.length ? m = null : m = Db(m);
                        m != p && (k = !0)
                    }
                    null != m ? e[l] = m : k = !0
                }
                if (k) {
                    for (let l in e) {
                        f = e;
                        break a
                    }
                    f = null
                }
            }
            f != h && (d = !0);c--;
            continue
        }
        null == h && c == g + 1 ? (d = !0, c--) : d && (b || (b = a.slice(0, c)), b[g] = h)
    }
    if (!d) return a;
    b || (b = a.slice(0, c));
    f && b.push(f);
    return b
}

function Gb(a, b) {
    b.m && (a.m = b.m.slice());
    const c = b.h;
    if (c) {
        b = b.i;
        for (let f in c) {
            const g = c[f];
            if (g) {
                var d = !(!b || !b[f]),
                    e = +f;
                if (Array.isArray(g)) {
                    if (g.length)
                        for (d = pb(a, g[0].constructor, e, d), e = 0; e < Math.min(d.length, g.length); e++) Gb(d[e], g[e])
                } else(d = ob(a, g.constructor, e, void 0, d)) && Gb(d, g)
            }
        }
    }
};
var Hb = class extends Cb {};
const Ib = () => {
    Object.defineProperties(Hb, {
        [Symbol.hasInstance]: {
            value: Object[Symbol.hasInstance],
            configurable: !1,
            writable: !1,
            enumerable: !1
        }
    })
};
kb && Ib();
const Jb = Symbol();

function Kb(a, b, c) {
    return a[Jb] || (a[Jb] = (d, e) => b(d, e, c))
}

function Lb(a) {
    let b = a[Jb];
    if (!b) {
        const c = Mb(a);
        b = (d, e) => Nb(d, e, c);
        a[Jb] = b
    }
    return b
}

function Ob(a) {
    var b = a.nb;
    if (b) return Lb(b);
    if (b = a.vb) return Kb(a.ta.h, b, a.ub)
}

function Pb(a) {
    const b = Ob(a),
        c = a.ta,
        d = a.Ab.T;
    return b ? (e, f) => d(e, f, c, b) : (e, f) => d(e, f, c)
}
const Qb = Symbol();

function Rb(a, b) {
    a[0] = b
}

function Sb(a, b, c, d) {
    const e = c.T;
    a[b] = d ? (f, g, h) => e(f, g, h, d) : e
}

function Tb(a, b, c, d, e, f) {
    const g = c.T,
        h = Lb(e);
    a[b] = (k, l, m) => g(k, l, m, d, h, f)
}

function Ub(a, b, c, d, e, f, g) {
    const h = c.T,
        k = Kb(d, e, f);
    a[b] = (l, m, p) => h(l, m, p, d, k, g)
}

function Mb(a) {
    var b = a[Qb];
    if (!b) {
        b = a[Qb] = {};
        var c = Rb,
            d = Sb,
            e = Tb,
            f = Ub;
        a = a();
        let h = 0;
        a.length && "number" !== typeof a[0] && (c(b, a[0]), h++);
        for (; h < a.length;) {
            c = a[h++];
            for (var g = h + 1; g < a.length && "number" !== typeof a[g];) g++;
            const k = a[h++];
            g -= h;
            switch (g) {
                case 0:
                    d(b, c, k);
                    break;
                case 1:
                    d(b, c, k, a[h++]);
                    break;
                case 2:
                    e(b, c, k, a[h++], a[h++]);
                    break;
                case 3:
                    g = a[h++];
                    const l = a[h++],
                        m = a[h++];
                    Array.isArray(m) ? e(b, c, k, g, l, m) : f(b, c, k, g, l, m);
                    break;
                case 4:
                    f(b, c, k, a[h++], a[h++], a[h++], a[h++]);
                    break;
                default:
                    throw Error("unexpected number of binary field arguments: " +
                        g);
            }
        }
    }
    return b
}

function Nb(a, b, c) {
    for (; ab(b) && 4 != b.i;) {
        var d = b.j,
            e = c[d];
        if (!e) {
            var f = c[0];
            f && (f = f[d]) && (e = c[d] = Pb(f))
        }
        if (!e || !e(b, a, d)) {
            e = b;
            d = a;
            var g = e.l;
            bb(e);
            e.ga || (f = e.h.j, e = e.h.h, e = g === e ? Sa || (Sa = new Uint8Array(0)) : Ua ? f.slice(g, e) : new Uint8Array(f.subarray(g, e)), (f = d.m) ? f.push(e) : d.m = [e])
        }
    }
    return a
}
var Xb = a => {
    var b = Vb,
        c = Wb;
    if (db.length) {
        const e = db.pop();
        if (a) {
            var d = e;
            Wa(d.h, a);
            d.j = -1;
            d.i = -1
        }
        a = e
    } else a = new cb(a);
    try {
        return Nb(new b, a, Mb(c))
    } finally {
        a.h.clear(), a.j = -1, a.i = -1, 100 > db.length && db.push(a)
    }
};

function Yb(a, b) {
    return {
        T: a,
        Gb: b
    }
}
var Zb = Yb(function(a, b, c) {
        if (2 !== a.i) return !1;
        var d = Ya(a.h);
        a = a.h;
        var e = a.h;
        a.h += d;
        Xa(a);
        a = a.j;
        var f;
        if (Ia)(f = Ha) || (f = Ha = new TextDecoder("utf-8", {
            fatal: !1
        })), f = f.decode(a.subarray(e, e + d));
        else {
            d = e + d;
            const h = [];
            let k = null;
            let l, m;
            for (; e < d;) {
                var g = a[e++];
                128 > g ? h.push(g) : 224 > g ? e >= d ? h.push(65533) : (l = a[e++], 194 > g || 128 !== (l & 192) ? (e--, h.push(65533)) : h.push((g & 31) << 6 | l & 63)) : 240 > g ? e >= d - 1 ? h.push(65533) : (l = a[e++], 128 !== (l & 192) || 224 === g && 160 > l || 237 === g && 160 <= l || 128 !== ((f = a[e++]) & 192) ? (e--, h.push(65533)) : h.push((g &
                    15) << 12 | (l & 63) << 6 | f & 63)) : 244 >= g ? e >= d - 2 ? h.push(65533) : (l = a[e++], 128 !== (l & 192) || 0 !== (g << 28) + (l - 144) >> 30 || 128 !== ((f = a[e++]) & 192) || 128 !== ((m = a[e++]) & 192) ? (e--, h.push(65533)) : (g = (g & 7) << 18 | (l & 63) << 12 | (f & 63) << 6 | m & 63, g -= 65536, h.push((g >> 10 & 1023) + 55296, (g & 1023) + 56320))) : h.push(65533);
                8192 <= h.length && (k = Ga(k, h), h.length = 0)
            }
            f = Ga(k, h)
        }
        B(b, c, f);
        return !0
    }, function(a, b, c) {
        a.i(c, A(b, c))
    }),
    $b = Yb(function(a, b, c, d, e) {
        if (2 !== a.i) return !1;
        var f = sb(b, c, d);
        b = a.h.i;
        c = Ya(a.h);
        d = a.h.h + c;
        a.h.i = d;
        e(f, a);
        e = d - a.h.h;
        if (0 !== e) throw Error("Message parsing ended unexpectedly. Expected to read " + `${c} bytes, instead read ${c-e} bytes, either the ` + "data ended unexpectedly or the message misreported its own length");
        a.h.h = d;
        a.h.i = b;
        return !0
    }, function(a, b, c, d, e) {
        a.h(c, pb(b, d, c), e)
    });

function ub(a, b) {
    const c = this.i;
    if (this.isRepeated) {
        let d;
        if (b) {
            d = gb([]);
            for (let e = 0; e < b.length; e++) d[e] = b[e].u;
            a.h || (a.h = {});
            a.h[c] = b
        } else a.h && (a.h[c] = void 0), d = jb;
        a = B(a, c, d, !0)
    } else a = C(a, c, b, !0);
    return a
};
class D extends Hb {}
const ac = () => {
    Object.defineProperties(D, {
        [Symbol.hasInstance]: {
            value: Object[Symbol.hasInstance],
            configurable: !1,
            writable: !1,
            enumerable: !1
        }
    })
};
kb && ac();
wa("csi.gstatic.com");
wa("googleads.g.doubleclick.net");
wa("partner.googleadservices.com");
wa("pubads.g.doubleclick.net");
wa("securepubads.g.doubleclick.net");
wa("tpc.googlesyndication.com");
/*

 SPDX-License-Identifier: Apache-2.0
*/
function bc(a) {
    if (!a) return "";
    if (/^about:(?:blank|srcdoc)$/.test(a)) return window.origin || "";
    a = a.split("#")[0].split("?")[0];
    a = a.toLowerCase();
    0 == a.indexOf("//") && (a = window.location.protocol + a);
    /^[\w\-]*:\/\//.test(a) || (a = window.location.href);
    var b = a.substring(a.indexOf("://") + 3),
        c = b.indexOf("/"); - 1 != c && (b = b.substring(0, c));
    c = a.substring(0, a.indexOf("://"));
    if (!c) throw Error("URI is missing protocol: " + a);
    if ("http" !== c && "https" !== c && "chrome-extension" !== c && "moz-extension" !== c && "file" !== c && "android-app" !==
        c && "chrome-search" !== c && "chrome-untrusted" !== c && "chrome" !== c && "app" !== c && "devtools" !== c) throw Error("Invalid URI scheme in origin: " + c);
    a = "";
    var d = b.indexOf(":");
    if (-1 != d) {
        var e = b.substring(d + 1);
        b = b.substring(0, d);
        if ("http" === c && "80" !== e || "https" === c && "443" !== e) a = ":" + e
    }
    return c + "://" + b + a
};
var cc = "client_dev_mss_url client_dev_regex_map client_dev_root_url client_rollout_override expflag jsfeat jsmode mods".split(" ");

function dc() {
    function a() {
        e[0] = 1732584193;
        e[1] = 4023233417;
        e[2] = 2562383102;
        e[3] = 271733878;
        e[4] = 3285377520;
        m = l = 0
    }

    function b(p) {
        for (var u = g, n = 0; 64 > n; n += 4) u[n / 4] = p[n] << 24 | p[n + 1] << 16 | p[n + 2] << 8 | p[n + 3];
        for (n = 16; 80 > n; n++) p = u[n - 3] ^ u[n - 8] ^ u[n - 14] ^ u[n - 16], u[n] = (p << 1 | p >>> 31) & 4294967295;
        p = e[0];
        var x = e[1],
            G = e[2],
            H = e[3],
            P = e[4];
        for (n = 0; 80 > n; n++) {
            if (40 > n)
                if (20 > n) {
                    var Q = H ^ x & (G ^ H);
                    var ka = 1518500249
                } else Q = x ^ G ^ H, ka = 1859775393;
            else 60 > n ? (Q = x & G | H & (x | G), ka = 2400959708) : (Q = x ^ G ^ H, ka = 3395469782);
            Q = ((p << 5 | p >>> 27) & 4294967295) + Q + P + ka + u[n] & 4294967295;
            P = H;
            H = G;
            G = (x << 30 | x >>> 2) & 4294967295;
            x = p;
            p = Q
        }
        e[0] = e[0] + p & 4294967295;
        e[1] = e[1] + x & 4294967295;
        e[2] = e[2] + G & 4294967295;
        e[3] = e[3] + H & 4294967295;
        e[4] = e[4] + P & 4294967295
    }

    function c(p, u) {
        if ("string" === typeof p) {
            p = unescape(encodeURIComponent(p));
            for (var n = [], x = 0, G = p.length; x < G; ++x) n.push(p.charCodeAt(x));
            p = n
        }
        u || (u = p.length);
        n = 0;
        if (0 == l)
            for (; n + 64 < u;) b(p.slice(n, n + 64)), n += 64, m += 64;
        for (; n < u;)
            if (f[l++] = p[n++], m++, 64 == l)
                for (l = 0, b(f); n + 64 < u;) b(p.slice(n, n + 64)), n += 64, m += 64
    }

    function d() {
        var p = [],
            u = 8 * m;
        56 > l ? c(h, 56 - l) : c(h, 64 - (l - 56));
        for (var n = 63; 56 <= n; n--) f[n] = u & 255, u >>>= 8;
        b(f);
        for (n = u = 0; 5 > n; n++)
            for (var x = 24; 0 <= x; x -= 8) p[u++] = e[n] >> x & 255;
        return p
    }
    for (var e = [], f = [], g = [], h = [128], k = 1; 64 > k; ++k) h[k] = 0;
    var l, m;
    a();
    return {
        reset: a,
        update: c,
        digest: d,
        ra: function() {
            for (var p = d(), u = "", n = 0; n < p.length; n++) u += "0123456789ABCDEF".charAt(Math.floor(p[n] / 16)) + "0123456789ABCDEF".charAt(p[n] % 16);
            return u
        }
    }
};

function ec(a, b, c) {
    var d = String(t.location.href);
    return d && a && b ? [b, fc(bc(d), a, c || null)].join(" ") : null
}

function fc(a, b, c) {
    var d = [],
        e = [];
    if (1 == (Array.isArray(c) ? 2 : 1)) return e = [b, a], oa(d, function(h) {
        e.push(h)
    }), gc(e.join(" "));
    var f = [],
        g = [];
    oa(c, function(h) {
        g.push(h.key);
        f.push(h.value)
    });
    c = Math.floor((new Date).getTime() / 1E3);
    e = 0 == f.length ? [c, b, a] : [f.join(":"), c, b, a];
    oa(d, function(h) {
        e.push(h)
    });
    a = gc(e.join(" "));
    a = [c, a];
    0 == g.length || a.push(g.join(""));
    return a.join("_")
}

function gc(a) {
    var b = dc();
    b.update(a);
    return b.ra().toLowerCase()
};
const hc = {};

function ic() {
    this.h = document || {
        cookie: ""
    }
}
q = ic.prototype;
q.isEnabled = function() {
    if (!t.navigator.cookieEnabled) return !1;
    if (!this.isEmpty()) return !0;
    this.set("TESTCOOKIESENABLED", "1", {
        la: 60
    });
    if ("1" !== this.get("TESTCOOKIESENABLED")) return !1;
    this.remove("TESTCOOKIESENABLED");
    return !0
};
q.set = function(a, b, c) {
    let d;
    var e = !1;
    let f;
    if ("object" === typeof c) {
        f = c.Eb;
        e = c.Fb || !1;
        d = c.domain || void 0;
        var g = c.path || void 0;
        var h = c.la
    }
    if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
    if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
    void 0 === h && (h = -1);
    c = d ? ";domain=" + d : "";
    g = g ? ";path=" + g : "";
    e = e ? ";secure" : "";
    h = 0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString();
    this.h.cookie = a + "=" + b + c + g + h + e + (null != f ? ";samesite=" +
        f : "")
};
q.get = function(a, b) {
    const c = a + "=",
        d = (this.h.cookie || "").split(";");
    for (let e = 0, f; e < d.length; e++) {
        f = ya(d[e]);
        if (0 == f.lastIndexOf(c, 0)) return f.substr(c.length);
        if (f == a) return ""
    }
    return b
};
q.remove = function(a, b, c) {
    const d = void 0 !== this.get(a);
    this.set(a, "", {
        la: 0,
        path: b,
        domain: c
    });
    return d
};
q.isEmpty = function() {
    return !this.h.cookie
};
q.clear = function() {
    var a = (this.h.cookie || "").split(";");
    const b = [],
        c = [];
    let d, e;
    for (let f = 0; f < a.length; f++) e = ya(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
    for (a = b.length - 1; 0 <= a; a--) this.remove(b[a])
};

function jc() {
    return !!hc.FPA_SAMESITE_PHASE2_MOD || !1
}

function kc(a, b, c, d) {
    (a = t[a]) || (a = (new ic).get(b));
    return a ? ec(a, c, d) : null
}

function lc() {
    var a = [],
        b = bc(String(t.location.href));
    const c = [];
    var d = t.__SAPISID || t.__APISID || t.__3PSAPISID || t.__OVERRIDE_SID;
    jc() && (d = d || t.__1PSAPISID);
    if (d) var e = !0;
    else e = new ic, d = e.get("SAPISID") || e.get("APISID") || e.get("__Secure-3PAPISID") || e.get("SID"), jc() && (d = d || e.get("__Secure-1PAPISID")), e = !!d;
    e && (d = (e = b = 0 == b.indexOf("https:") || 0 == b.indexOf("chrome-extension:") || 0 == b.indexOf("moz-extension:")) ? t.__SAPISID : t.__APISID, d || (d = new ic, d = d.get(e ? "SAPISID" : "APISID") || d.get("__Secure-3PAPISID")),
        (e = d ? ec(d, e ? "SAPISIDHASH" : "APISIDHASH", a) : null) && c.push(e), b && jc() && ((b = kc("__1PSAPISID", "__Secure-1PAPISID", "SAPISID1PHASH", a)) && c.push(b), (a = kc("__3PSAPISID", "__Secure-3PAPISID", "SAPISID3PHASH", a)) && c.push(a)));
    return 0 == c.length ? null : c.join(" ")
};

function mc() {
    this.j = this.j;
    this.l = this.l
}
mc.prototype.j = !1;
mc.prototype.dispose = function() {
    this.j || (this.j = !0, this.V())
};
mc.prototype.V = function() {
    if (this.l)
        for (; this.l.length;) this.l.shift()()
};

function nc(a) {
    var b = v("window.location.href");
    null == a && (a = 'Unknown Error of type "null/undefined"');
    if ("string" === typeof a) return {
        message: a,
        name: "Unknown error",
        lineNumber: "Not available",
        fileName: b,
        stack: "Not available"
    };
    var c = !1;
    try {
        var d = a.lineNumber || a.line || "Not available"
    } catch (g) {
        d = "Not available", c = !0
    }
    try {
        var e = a.fileName || a.filename || a.sourceURL || t.$googDebugFname || b
    } catch (g) {
        e = "Not available", c = !0
    }
    b = oc(a);
    if (!(!c && a.lineNumber && a.fileName && a.stack && a.message && a.name)) {
        c = a.message;
        if (null ==
            c) {
            if (a.constructor && a.constructor instanceof Function) {
                if (a.constructor.name) c = a.constructor.name;
                else if (c = a.constructor, pc[c]) c = pc[c];
                else {
                    c = String(c);
                    if (!pc[c]) {
                        var f = /function\s+([^\(]+)/m.exec(c);
                        pc[c] = f ? f[1] : "[Anonymous]"
                    }
                    c = pc[c]
                }
                c = 'Unknown Error of type "' + c + '"'
            } else c = "Unknown Error of unknown type";
            "function" === typeof a.toString && Object.prototype.toString !== a.toString && (c += ": " + a.toString())
        }
        return {
            message: c,
            name: a.name || "UnknownError",
            lineNumber: d,
            fileName: e,
            stack: b || "Not available"
        }
    }
    a.stack =
        b;
    return {
        message: a.message,
        name: a.name,
        lineNumber: a.lineNumber,
        fileName: a.fileName,
        stack: a.stack
    }
}

function oc(a, b) {
    b || (b = {});
    b[qc(a)] = !0;
    var c = a.stack || "";
    (a = a.qa) && !b[qc(a)] && (c += "\nCaused by: ", a.stack && 0 == a.stack.indexOf(a.toString()) || (c += "string" === typeof a ? a : a.message + "\n"), c += oc(a, b));
    return c
}

function qc(a) {
    var b = "";
    "function" === typeof a.toString && (b = "" + a);
    return b + a.stack
}
var pc = {};

function rc(a, b) {
    a.l(b);
    100 > a.i && (a.i++, b.next = a.h, a.h = b)
}
var sc = class {
    constructor(a, b) {
        this.j = a;
        this.l = b;
        this.i = 0;
        this.h = null
    }
    get() {
        let a;
        0 < this.i ? (this.i--, a = this.h, this.h = a.next, a.next = null) : a = this.j();
        return a
    }
};

function tc(a) {
    t.setTimeout(() => {
        throw a;
    }, 0)
};
class uc {
    constructor() {
        this.i = this.h = null
    }
    add(a, b) {
        const c = vc.get();
        c.set(a, b);
        this.i ? this.i.next = c : this.h = c;
        this.i = c
    }
    remove() {
        let a = null;
        this.h && (a = this.h, this.h = this.h.next, this.h || (this.i = null), a.next = null);
        return a
    }
}
var vc = new sc(() => new wc, a => a.reset());
class wc {
    constructor() {
        this.next = this.scope = this.h = null
    }
    set(a, b) {
        this.h = a;
        this.scope = b;
        this.next = null
    }
    reset() {
        this.next = this.scope = this.h = null
    }
};

function xc(a, b) {
    yc || zc();
    Ac || (yc(), Ac = !0);
    Bc.add(a, b)
}
var yc;

function zc() {
    var a = t.Promise.resolve(void 0);
    yc = function() {
        a.then(Cc)
    }
}
var Ac = !1,
    Bc = new uc;

function Cc() {
    for (var a; a = Bc.remove();) {
        try {
            a.h.call(a.scope)
        } catch (b) {
            tc(b)
        }
        rc(vc, a)
    }
    Ac = !1
};
class Dc {
    constructor() {
        this.promise = new Promise((a, b) => {
            this.reject = b
        })
    }
};

function E(a) {
    this.h = 0;
    this.C = void 0;
    this.l = this.i = this.j = null;
    this.m = this.o = !1;
    if (a != ha) try {
        var b = this;
        a.call(void 0, function(c) {
            Ec(b, 2, c)
        }, function(c) {
            Ec(b, 3, c)
        })
    } catch (c) {
        Ec(this, 3, c)
    }
}

function Fc() {
    this.next = this.context = this.onRejected = this.i = this.h = null;
    this.j = !1
}
Fc.prototype.reset = function() {
    this.context = this.onRejected = this.i = this.h = null;
    this.j = !1
};
var Gc = new sc(function() {
    return new Fc
}, function(a) {
    a.reset()
});

function Hc(a, b, c) {
    var d = Gc.get();
    d.i = a;
    d.onRejected = b;
    d.context = c;
    return d
}

function Ic(a) {
    if (a instanceof E) return a;
    var b = new E(ha);
    Ec(b, 2, a);
    return b
}
E.prototype.then = function(a, b, c) {
    return Jc(this, "function" === typeof a ? a : null, "function" === typeof b ? b : null, c)
};
E.prototype.$goog_Thenable = !0;
q = E.prototype;
q.Ha = function(a, b) {
    return Jc(this, null, a, b)
};
q.catch = E.prototype.Ha;
q.cancel = function(a) {
    if (0 == this.h) {
        var b = new Kc(a);
        xc(function() {
            Lc(this, b)
        }, this)
    }
};

function Lc(a, b) {
    if (0 == a.h)
        if (a.j) {
            var c = a.j;
            if (c.i) {
                for (var d = 0, e = null, f = null, g = c.i; g && (g.j || (d++, g.h == a && (e = g), !(e && 1 < d))); g = g.next) e || (f = g);
                e && (0 == c.h && 1 == d ? Lc(c, b) : (f ? (d = f, d.next == c.l && (c.l = d), d.next = d.next.next) : Mc(c), Nc(c, e, 3, b)))
            }
            a.j = null
        } else Ec(a, 3, b)
}

function Oc(a, b) {
    a.i || 2 != a.h && 3 != a.h || Pc(a);
    a.l ? a.l.next = b : a.i = b;
    a.l = b
}

function Jc(a, b, c, d) {
    var e = Hc(null, null, null);
    e.h = new E(function(f, g) {
        e.i = b ? function(h) {
            try {
                var k = b.call(d, h);
                f(k)
            } catch (l) {
                g(l)
            }
        } : f;
        e.onRejected = c ? function(h) {
            try {
                var k = c.call(d, h);
                void 0 === k && h instanceof Kc ? g(h) : f(k)
            } catch (l) {
                g(l)
            }
        } : g
    });
    e.h.j = a;
    Oc(a, e);
    return e.h
}
q.Ia = function(a) {
    this.h = 0;
    Ec(this, 2, a)
};
q.Ja = function(a) {
    this.h = 0;
    Ec(this, 3, a)
};

function Ec(a, b, c) {
    if (0 == a.h) {
        a === c && (b = 3, c = new TypeError("Promise cannot resolve to itself"));
        a.h = 1;
        a: {
            var d = c,
                e = a.Ia,
                f = a.Ja;
            if (d instanceof E) {
                Oc(d, Hc(e || ha, f || null, a));
                var g = !0
            } else {
                if (d) try {
                    var h = !!d.$goog_Thenable
                } catch (l) {
                    h = !1
                } else h = !1;
                if (h) d.then(e, f, a), g = !0;
                else {
                    h = typeof d;
                    if ("object" == h && null != d || "function" == h) try {
                        var k = d.then;
                        if ("function" === typeof k) {
                            Qc(d, k, e, f, a);
                            g = !0;
                            break a
                        }
                    } catch (l) {
                        f.call(a, l);
                        g = !0;
                        break a
                    }
                    g = !1
                }
            }
        }
        g || (a.C = c, a.h = b, a.j = null, Pc(a), 3 != b || c instanceof Kc || Rc(a, c))
    }
}

function Qc(a, b, c, d, e) {
    function f(k) {
        h || (h = !0, d.call(e, k))
    }

    function g(k) {
        h || (h = !0, c.call(e, k))
    }
    var h = !1;
    try {
        b.call(a, g, f)
    } catch (k) {
        f(k)
    }
}

function Pc(a) {
    a.o || (a.o = !0, xc(a.sa, a))
}

function Mc(a) {
    var b = null;
    a.i && (b = a.i, a.i = b.next, b.next = null);
    a.i || (a.l = null);
    return b
}
q.sa = function() {
    for (var a; a = Mc(this);) Nc(this, a, this.h, this.C);
    this.o = !1
};

function Nc(a, b, c, d) {
    if (3 == c && b.onRejected && !b.j)
        for (; a && a.m; a = a.j) a.m = !1;
    if (b.h) b.h.j = null, Sc(b, c, d);
    else try {
        b.j ? b.i.call(b.context) : Sc(b, c, d)
    } catch (e) {
        Tc.call(null, e)
    }
    rc(Gc, b)
}

function Sc(a, b, c) {
    2 == b ? a.i.call(a.context, c) : a.onRejected && a.onRejected.call(a.context, c)
}

function Rc(a, b) {
    a.m = !0;
    xc(function() {
        a.m && Tc.call(null, b)
    })
}
var Tc = tc;

function Kc(a) {
    na.call(this, a)
}
ma(Kc, na);
Kc.prototype.name = "cancel";

function F(a) {
    mc.call(this);
    this.C = 1;
    this.m = [];
    this.o = 0;
    this.h = [];
    this.i = {};
    this.M = !!a
}
ma(F, mc);
q = F.prototype;
q.subscribe = function(a, b, c) {
    var d = this.i[a];
    d || (d = this.i[a] = []);
    var e = this.C;
    this.h[e] = a;
    this.h[e + 1] = b;
    this.h[e + 2] = c;
    this.C = e + 3;
    d.push(e);
    return e
};
q.ca = function(a) {
    var b = this.h[a];
    if (b) {
        var c = this.i[b];
        if (0 != this.o) this.m.push(a), this.h[a + 1] = ha;
        else {
            if (c) {
                var d = Array.prototype.indexOf.call(c, a, void 0);
                0 <= d && Array.prototype.splice.call(c, d, 1)
            }
            delete this.h[a];
            delete this.h[a + 1];
            delete this.h[a + 2]
        }
    }
    return !!b
};
q.Z = function(a, b) {
    var c = this.i[a];
    if (c) {
        for (var d = Array(arguments.length - 1), e = 1, f = arguments.length; e < f; e++) d[e - 1] = arguments[e];
        if (this.M)
            for (e = 0; e < c.length; e++) {
                var g = c[e];
                Uc(this.h[g + 1], this.h[g + 2], d)
            } else {
                this.o++;
                try {
                    for (e = 0, f = c.length; e < f && !this.j; e++) g = c[e], this.h[g + 1].apply(this.h[g + 2], d)
                } finally {
                    if (this.o--, 0 < this.m.length && 0 == this.o)
                        for (; c = this.m.pop();) this.ca(c)
                }
            }
        return 0 != e
    }
    return !1
};

function Uc(a, b, c) {
    xc(function() {
        a.apply(b, c)
    })
}
q.clear = function(a) {
    if (a) {
        var b = this.i[a];
        b && (b.forEach(this.ca, this), delete this.i[a])
    } else this.h.length = 0, this.i = {}
};
q.V = function() {
    F.Ea.V.call(this);
    this.clear();
    this.m.length = 0
};
/*

Math.uuid.js (v1.4)
http://www.broofa.com
mailto:robert@broofa.com
Copyright (c) 2010 Robert Kieffer
Dual licensed under the MIT and GPL licenses.
*/
var Vc = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
var Xc = class extends D {
        constructor(a) {
            super(a)
        }
        getKey() {
            return A(this, 1)
        }
        ia() {
            return A(this, 2 === nb(this, Wc) ? 2 : -1)
        }
        setValue(a) {
            return mb(this, 2, Wc, a)
        }
    },
    Wc = [2, 3, 4, 5, 6];
var Yc = class extends D {
    constructor(a) {
        super(a)
    }
};
var $c = class extends D {
        constructor() {
            super(void 0, -1, Zc)
        }
        getPlayerType() {
            return A(this, 36)
        }
        setHomeGroupInfo(a) {
            return C(this, 81, a)
        }
    },
    Zc = [9, 66, 24, 32, 86, 100, 101];
var bd = class extends D {
        constructor() {
            super(void 0, -1, ad)
        }
    },
    ad = [15, 26, 28];
var cd = class extends D {
    constructor(a) {
        super(a)
    }
    setToken(a) {
        return B(this, 2, a)
    }
};
var ed = class extends D {
        constructor(a) {
            super(a, -1, dd)
        }
        setSafetyMode(a) {
            return B(this, 5, a)
        }
    },
    dd = [12];
var gd = class extends D {
        constructor(a) {
            super(a, -1, fd)
        }
    },
    fd = [12];
var hd = class extends D {
    constructor(a) {
        super(a)
    }
};
var id = {
    eb: 0,
    Oa: 1,
    Ua: 2,
    Va: 4,
    ab: 8,
    Wa: 16,
    Xa: 32,
    cb: 64,
    bb: 128,
    Qa: 256,
    Sa: 512,
    Za: 1024,
    Ra: 2048,
    Ta: 4096,
    Pa: 8192,
    Ya: 16384
};

function jd(a, b) {
    C(a, 1, b)
}
var kd = class extends D {
    constructor() {
        super(void 0)
    }
    B(a) {
        B(this, 2, a)
    }
};

function ld(a, b) {
    C(a, 1, b)
}
var md = class extends D {
    constructor() {
        super(void 0)
    }
};

function nd(a, b) {
    C(a, 2, b)
}
var pd = class extends D {
        constructor() {
            super(void 0, -1, od)
        }
        B(a) {
            B(this, 1, a)
        }
    },
    od = [3];
var qd = class extends D {
    constructor() {
        super(void 0)
    }
    B(a) {
        B(this, 1, a)
    }
};
var rd = class extends D {
    constructor() {
        super(void 0)
    }
    B(a) {
        B(this, 1, a)
    }
};
var sd = class extends D {
    constructor() {
        super(void 0)
    }
    B(a) {
        B(this, 1, a)
    }
};
var td = class extends D {
    constructor() {
        super(void 0)
    }
};
var ud = class extends D {
    constructor() {
        super(void 0)
    }
};
var vd = class extends D {
        constructor(a) {
            super(a, 424)
        }
    },
    rb = [23, 24, 11, 6, 7, 5, 2, 3, 20, 21, 28, 32, 37, 229, 241, 45, 59, 225, 288, 72, 73, 78, 208, 156, 202, 215, 74, 76, 79, 80, 111, 85, 91, 97, 100, 102, 105, 119, 126, 127, 136, 146, 157, 158, 159, 163, 164, 168, 176, 222, 383, 177, 178, 179, 411, 184, 188, 189, 190, 191, 193, 194, 195, 196, 198, 199, 200, 201, 203, 204, 205, 206, 258, 259, 260, 261, 209, 226, 227, 232, 233, 234, 240, 247, 248, 251, 254, 255, 270, 278, 291, 293, 300, 304, 308, 309, 310, 311, 313, 314, 319, 321, 323, 324, 328, 330, 331, 332, 337, 338, 340, 344, 348, 350, 351, 352, 353, 354, 355,
        356, 357, 358, 361, 363, 364, 368, 369, 370, 373, 374, 375, 378, 380, 381, 388, 389, 403, 412, 413, 414, 415, 416, 417, 418, 419, 420, 423, 117
    ];
var wd = class extends D {
    constructor() {
        super(void 0)
    }
};
var yd = class extends D {
        constructor() {
            super(void 0)
        }
        setVideoId(a) {
            return mb(this, 1, xd, a)
        }
        getPlaylistId() {
            return A(this, 2 === nb(this, xd) ? 2 : -1)
        }
    },
    xd = [1, 2];
var Ad = class extends D {
        constructor() {
            super(void 0, -1, zd)
        }
    },
    zd = [3];
var Bd = ["notification/convert_endpoint_to_url"],
    Cd = ["notification/record_interactions"],
    Dd = ["notification_registration/set_registration"];
var Ed = class extends D {
    constructor(a) {
        super(a, 1)
    }
};
var Fd = class extends D {
        constructor(a) {
            super(a)
        }
    },
    Gd = function(a, b, c, d, e = 0) {
        return new tb(a, b, c, e)
    }(406606992, {
        rb: 0
    }, Fd, void 0);
var Hd = class extends Fd {};
const Id = t.window;
let Jd, Kd;
const I = (null == Id ? void 0 : null == (Jd = Id.yt) ? void 0 : Jd.config_) || (null == Id ? void 0 : null == (Kd = Id.ytcfg) ? void 0 : Kd.data_) || {};
let Ld;
const Md = (null == Id ? void 0 : null == (Ld = Id.ytcfg) ? void 0 : Ld.obfuscatedData_) || [];
let Nd = new class extends Ed {}(Md);
const Od = I.EXPERIMENT_FLAGS;
if (!Od || !Od.jspb_i18n_extension) {
    var Pd = new Hd;
    Gd.j(Nd, Pd)
}
w("yt.config_", I);
w("yt.configJspb_", Md);

function J(...a) {
    a = arguments;
    1 < a.length ? I[a[0]] = a[1] : 1 === a.length && Object.assign(I, a[0])
}

function K(a, b) {
    return a in I ? I[a] : b
};

function L(a) {
    a = Qd(a);
    return "string" === typeof a && "false" === a ? !1 : !!a
}

function Rd(a, b) {
    a = Qd(a);
    return void 0 === a && void 0 !== b ? b : Number(a || 0)
}

function Sd() {
    return K("EXPERIMENTS_TOKEN", "")
}

function Qd(a) {
    const b = K("EXPERIMENTS_FORCED_FLAGS", {});
    return void 0 !== b[a] ? b[a] : K("EXPERIMENT_FLAGS", {})[a]
}

function Td() {
    const a = [],
        b = K("EXPERIMENTS_FORCED_FLAGS", {});
    for (var c in b) a.push({
        key: c,
        value: String(b[c])
    });
    c = K("EXPERIMENT_FLAGS", {});
    for (let d in c) d.startsWith("force_") && void 0 === b[d] && a.push({
        key: d,
        value: String(c[d])
    });
    return a
};
let Ud = 0;
w("ytDomDomGetNextId", v("ytDomDomGetNextId") || (() => ++Ud));
const Vd = [];

function Wd(a) {
    Vd.forEach(b => b(a))
}

function Xd(a) {
    return a && window.yterr ? function() {
        try {
            return a.apply(this, arguments)
        } catch (b) {
            Yd(b)
        }
    } : a
}

function Yd(a) {
    var b = v("yt.logging.errors.log");
    b ? b(a, "ERROR", void 0, void 0, void 0) : (b = K("ERRORS", []), b.push([a, "ERROR", void 0, void 0, void 0]), J("ERRORS", b));
    Wd(a)
}

function Zd(a) {
    var b = v("yt.logging.errors.log");
    b ? b(a, "WARNING", void 0, void 0, void 0) : (b = K("ERRORS", []), b.push([a, "WARNING", void 0, void 0, void 0]), J("ERRORS", b))
};
w("ytEventsEventsListeners", t.ytEventsEventsListeners || {});
w("ytEventsEventsCounter", t.ytEventsEventsCounter || {
    count: 0
});

function $d(a, b) {
    "function" === typeof a && (a = Xd(a));
    return window.setTimeout(a, b)
};

function ae(a, b) {
    be(a, 2, b)
}
var ce = class {
    h(a) {
        be(a, 1, void 0)
    }
};

function be(a, b, c) {
    void 0 !== c && Number.isNaN(Number(c)) && (c = void 0);
    const d = v("yt.scheduler.instance.addJob");
    d ? d(a, b, c) : void 0 === c ? a() : $d(a, c || 0)
}
var de = class extends ce {
    start() {
        const a = v("yt.scheduler.instance.start");
        a && a()
    }
};
de.h || (de.h = new de);
var ee = de.h;

function fe() {
    const a = v("_lact", window);
    var b;
    null == a ? b = -1 : b = Math.max(Date.now() - a, 0);
    return b
};
const ge = /^[\w.]*$/,
    he = {
        q: !0,
        search_query: !0
    };

function ie(a, b) {
    b = a.split(b);
    const c = {};
    for (let f = 0, g = b.length; f < g; f++) {
        const h = b[f].split("=");
        if (1 == h.length && h[0] || 2 == h.length) try {
            const k = je(h[0] || ""),
                l = je(h[1] || "");
            k in c ? Array.isArray(c[k]) ? qa(c[k], l) : c[k] = [c[k], l] : c[k] = l
        } catch (k) {
            var d = k,
                e = h[0];
            const l = String(ie);
            d.args = [{
                key: e,
                value: h[1],
                query: a,
                method: ke == l ? "unchanged" : l
            }];
            he.hasOwnProperty(e) || Zd(d)
        }
    }
    return c
}
const ke = String(ie);

function le(a) {
    "?" == a.charAt(0) && (a = a.substr(1));
    return ie(a, "&")
}

function me(a, b, c) {
    var d = a.split("#", 2);
    a = d[0];
    d = 1 < d.length ? "#" + d[1] : "";
    var e = a.split("?", 2);
    a = e[0];
    e = le(e[1] || "");
    for (var f in b) !c && null !== e && f in e || (e[f] = b[f]);
    b = a;
    a = Da(e);
    a ? (c = b.indexOf("#"), 0 > c && (c = b.length), f = b.indexOf("?"), 0 > f || f > c ? (f = c, e = "") : e = b.substring(f + 1, c), b = [b.substr(0, f), e, b.substr(c)], c = b[1], b[1] = a ? c ? c + "&" + a : a : c, a = b[0] + (b[1] ? "?" + b[1] : "") + b[2]) : a = b;
    return a + d
}

function ne(a) {
    if (!b) var b = window.location.href;
    const c = a.match(z)[1] || null,
        d = Ba(a.match(z)[3] || null);
    c && d ? (a = a.match(z), b = b.match(z), a = a[3] == b[3] && a[1] == b[1] && a[4] == b[4]) : a = d ? Ba(b.match(z)[3] || null) == d && (Number(b.match(z)[4] || null) || null) == (Number(a.match(z)[4] || null) || null) : !0;
    return a
}

function je(a) {
    return a && a.match(ge) ? a : decodeURIComponent(a.replace(/\+/g, " "))
};
Date.now();
[...cc];
let oe = !1;

function pe(a, b) {
    const c = {
        method: b.method || "GET",
        credentials: "same-origin"
    };
    b.headers && (c.headers = b.headers);
    a = qe(a, b);
    const d = re(a, b);
    d && (c.body = d);
    b.withCredentials && (c.credentials = "include");
    const e = b.context || t;
    let f = !1,
        g;
    fetch(a, c).then(h => {
        if (!f) {
            f = !0;
            g && window.clearTimeout(g);
            var k = h.ok,
                l = m => {
                    m = m || {};
                    k ? b.onSuccess && b.onSuccess.call(e, m, h) : b.onError && b.onError.call(e, m, h);
                    b.onFinish && b.onFinish.call(e, m, h)
                };
            "JSON" == (b.format || "JSON") && (k || 400 <= h.status && 500 > h.status) ? h.json().then(l, function() {
                l(null)
            }): l(null)
        }
    }).catch(() => {
        b.onError && b.onError.call(e, {}, {})
    });
    b.onFetchTimeout && 0 < b.timeout && (g = $d(() => {
        f || (f = !0, window.clearTimeout(g), b.onFetchTimeout.call(b.context || t))
    }, b.timeout))
}

function qe(a, b) {
    b.includeDomain && (a = document.location.protocol + "//" + document.location.hostname + (document.location.port ? ":" + document.location.port : "") + a);
    const c = K("XSRF_FIELD_NAME", void 0);
    if (b = b.urlParams) b[c] && delete b[c], a = me(a, b || {}, !0);
    return a
}

function re(a, b) {
    const c = K("XSRF_FIELD_NAME", void 0),
        d = K("XSRF_TOKEN", void 0);
    var e = b.postBody || "",
        f = b.postParams;
    const g = K("XSRF_FIELD_NAME", void 0);
    let h;
    b.headers && (h = b.headers["Content-Type"]);
    b.excludeXsrf || Ba(a.match(z)[3] || null) && !b.withCredentials && Ba(a.match(z)[3] || null) != document.location.hostname || "POST" != b.method || h && "application/x-www-form-urlencoded" != h || b.postParams && b.postParams[g] || (f || (f = {}), f[c] = d);
    f && "string" === typeof e && (e = le(e), ua(e, f), e = b.postBodyFormat && "JSON" == b.postBodyFormat ?
        JSON.stringify(e) : Da(e));
    f = e || f && !ra(f);
    !oe && f && "POST" != b.method && (oe = !0, Yd(Error("AJAX request with postData should use POST")));
    return e
};
t.ytPubsubPubsubInstance || new F;
const se = window;
var M = se.ytcsi && se.ytcsi.now ? se.ytcsi.now : se.performance && se.performance.timing && se.performance.now && se.performance.timing.navigationStart ? () => se.performance.timing.navigationStart + se.performance.now() : () => (new Date).getTime();
const te = Rd("initial_gel_batch_timeout", 2E3),
    ue = Math.pow(2, 16) - 1;
let N = void 0;
class ve {
    constructor() {
        this.j = this.h = this.i = 0
    }
}
const we = new ve,
    xe = new ve;
let ye = !0;
const ze = t.ytLoggingTransportGELQueue_ || new Map,
    Ae = t.ytLoggingTransportGELProtoQueue_ || new Map,
    Be = t.ytLoggingTransportTokensToCttTargetIds_ || {},
    Ce = t.ytLoggingTransportTokensToJspbCttTargetIds_ || {};

function De(a, b) {
    if ("log_event" === a.endpoint) {
        var c = Ee(a),
            d = ze.get(c) || [];
        ze.set(c, d);
        d.push(a.payload);
        Fe(b, d, c)
    }
}

function Ge(a, b) {
    if ("log_event" === a.endpoint) {
        var c = Ee(a, !0),
            d = Ae.get(c) || [];
        Ae.set(c, d);
        d.push(a.payload);
        Fe(b, d, c, !0)
    }
}

function Fe(a, b, c, d = !1) {
    a && (N = new a);
    a = Rd("tvhtml5_logging_max_batch") || Rd("web_logging_max_batch") || 100;
    const e = M(),
        f = d ? xe.j : we.j;
    b.length >= a ? He({
        writeThenSend: !0
    }, L("flush_only_full_queue") ? c : void 0, d) : 10 <= e - f && (Ie(d), d ? xe.j = e : we.j = e)
}

function Je(a, b) {
    if ("log_event" === a.endpoint) {
        var c = Ee(a),
            d = new Map;
        d.set(c, [a.payload]);
        b && (N = new b);
        return new E(e => {
            N && N.isReady() ? Ke(d, e, {
                bypassNetworkless: !0
            }, !0) : e()
        })
    }
}

function Le(a, b) {
    if ("log_event" === a.endpoint) {
        var c = Ee(a, !0),
            d = new Map;
        d.set(c, [a.payload]);
        b && (N = new b);
        return new E(e => {
            N && N.isReady() ? Me(d, e, {
                bypassNetworkless: !0
            }, !0) : e()
        })
    }
}

function Ee(a, b = !1) {
    var c = "";
    if (a.K) c = "visitorOnlyApprovedKey";
    else if (a.cttAuthInfo) {
        if (b) {
            b = a.cttAuthInfo.token;
            c = a.cttAuthInfo;
            const d = new yd;
            c.videoId ? d.setVideoId(c.videoId) : c.playlistId && mb(d, 2, xd, c.playlistId);
            Ce[b] = d
        } else b = a.cttAuthInfo, c = {}, b.videoId ? c.videoId = b.videoId : b.playlistId && (c.playlistId = b.playlistId), Be[a.cttAuthInfo.token] = c;
        c = a.cttAuthInfo.token
    }
    return c
}

function He(a = {}, b, c = !1) {
    new E(d => {
        c ? (window.clearTimeout(xe.i), window.clearTimeout(xe.h), xe.h = 0) : (window.clearTimeout(we.i), window.clearTimeout(we.h), we.h = 0);
        if (N && N.isReady())
            if (void 0 !== b)
                if (c) {
                    var e = new Map,
                        f = Ae.get(b) || [];
                    e.set(b, f);
                    Me(e, d, a);
                    Ae.delete(b)
                } else e = new Map, f = ze.get(b) || [], e.set(b, f), Ke(e, d, a), ze.delete(b);
        else c ? (Me(Ae, d, a), Ae.clear()) : (Ke(ze, d, a), ze.clear());
        else Ie(c), d()
    })
}

function Ie(a = !1) {
    if (L("web_gel_timeout_cap") && (!a && !we.h || a && !xe.h)) {
        var b = $d(() => {
            He({
                writeThenSend: !0
            }, void 0, a)
        }, 6E4);
        a ? xe.h = b : we.h = b
    }
    window.clearTimeout(a ? xe.i : we.i);
    b = K("LOGGING_BATCH_TIMEOUT", Rd("web_gel_debounce_ms", 1E4));
    L("shorten_initial_gel_batch_timeout") && ye && (b = te);
    b = $d(() => {
        He({
            writeThenSend: !0
        }, void 0, a)
    }, b);
    a ? xe.i = b : we.i = b
}

function Ke(a, b, c = {}, d) {
    var e = N;
    const f = Math.round(M());
    let g = a.size;
    for (const [l, m] of a) {
        var h = l,
            k = m;
        a = sa({
            context: Ne(e.config_ || Oe())
        });
        a.events = k;
        (k = Be[h]) && Pe(a, h, k);
        delete Be[h];
        h = "visitorOnlyApprovedKey" === h;
        Qe(a, f, h);
        Re(c);
        Se(e, a, Te(c, h, () => {
            g--;
            g || b()
        }, () => {
            g--;
            g || b()
        }, d));
        ye = !1
    }
}

function Me(a, b, c = {}, d) {
    var e = N;
    const f = Math.round(M());
    let g = a.size;
    for (const [m, p] of a) {
        var h = m,
            k = p;
        a = new Ad;
        var l = Ue(e.config_ || Oe());
        C(a, 1, l);
        for (l = 0; l < k.length; l++) sb(a, 3, vd, k[l], void 0);
        (k = Ce[h]) && Ve(a, h, k);
        delete Ce[h];
        h = "visitorOnlyApprovedKey" === h;
        We(a, f, h);
        Re(c);
        a = Eb(a);
        h = Te(c, h, () => {
            g--;
            g || b()
        }, () => {
            g--;
            g || b()
        }, d);
        h.headers = {
            "Content-Type": "application/json+protobuf"
        };
        h.postBodyFormat = "JSPB";
        h.postBody = a;
        Se(e, "", h);
        ye = !1
    }
}

function Re(a) {
    L("always_send_and_write") && (a.writeThenSend = !1)
}

function Te(a, b, c, d, e) {
    return {
        retry: !0,
        onSuccess: c,
        onError: d,
        wb: a,
        K: b,
        ob: !!e,
        headers: {},
        postBodyFormat: "",
        postBody: ""
    }
}

function Qe(a, b, c) {
    a.requestTimeMs = String(b);
    L("unsplit_gel_payloads_in_logs") && (a.unsplitGelPayloadsInLogs = !0);
    !c && (b = K("EVENT_ID", void 0)) && (c = Xe(), a.serializedClientEventId = {
        serializedEventId: b,
        clientCounter: String(c)
    })
}

function We(a, b, c) {
    B(a, 2, b);
    if (!c && (b = K("EVENT_ID", void 0))) {
        c = Xe();
        const d = new wd;
        B(d, 1, b);
        B(d, 2, c);
        C(a, 5, d)
    }
}

function Xe() {
    let a = K("BATCH_CLIENT_COUNTER", void 0) || 0;
    a || (a = Math.floor(Math.random() * ue / 2));
    a++;
    a > ue && (a = 1);
    J("BATCH_CLIENT_COUNTER", a);
    return a
}

function Pe(a, b, c) {
    let d;
    if (c.videoId) d = "VIDEO";
    else if (c.playlistId) d = "PLAYLIST";
    else return;
    a.credentialTransferTokenTargetId = c;
    a.context = a.context || {};
    a.context.user = a.context.user || {};
    a.context.user.credentialTransferTokens = [{
        token: b,
        scope: d
    }]
}

function Ve(a, b, c) {
    let d;
    if (A(c, 1 === nb(c, xd) ? 1 : -1)) d = 1;
    else if (c.getPlaylistId()) d = 2;
    else return;
    C(a, 4, c);
    a = ob(a, gd, 1) || new gd;
    c = ob(a, ed, 3) || new ed;
    const e = new cd;
    e.setToken(b);
    B(e, 1, d);
    sb(c, 12, cd, e, void 0);
    C(a, 3, c)
};
const Ye = t.ytLoggingGelSequenceIdObj_ || {};

function O(a, b, c, d = {}) {
    const e = {},
        f = Math.round(d.timestamp || M());
    e.eventTimeMs = f < Number.MAX_SAFE_INTEGER ? f : 0;
    e[a] = b;
    a = fe();
    e.context = {
        lastActivityMs: String(d.timestamp || !isFinite(a) ? -1 : a)
    };
    L("log_sequence_info_on_gel_web") && d.A && (a = e.context, b = d.A, b = {
        index: Ze(b),
        groupKey: b
    }, a.sequence = b, d.ha && delete Ye[d.A]);
    (d.Da ? Je : De)({
        endpoint: "log_event",
        payload: e,
        cttAuthInfo: d.cttAuthInfo,
        K: d.K
    }, c)
}

function Ze(a) {
    Ye[a] = a in Ye ? Ye[a] + 1 : 0;
    return Ye[a]
};
w("ytglobal.prefsUserPrefsPrefs_", v("ytglobal.prefsUserPrefsPrefs_") || {});

function $e() {
    return "INNERTUBE_API_KEY" in I && "INNERTUBE_API_VERSION" in I
}

function Oe() {
    return {
        innertubeApiKey: K("INNERTUBE_API_KEY", void 0),
        innertubeApiVersion: K("INNERTUBE_API_VERSION", void 0),
        W: K("INNERTUBE_CONTEXT_CLIENT_CONFIG_INFO"),
        wa: K("INNERTUBE_CONTEXT_CLIENT_NAME", "WEB"),
        xa: K("INNERTUBE_CONTEXT_CLIENT_NAME", 1),
        innertubeContextClientVersion: K("INNERTUBE_CONTEXT_CLIENT_VERSION", void 0),
        ka: K("INNERTUBE_CONTEXT_HL", void 0),
        ja: K("INNERTUBE_CONTEXT_GL", void 0),
        ya: K("INNERTUBE_HOST_OVERRIDE", void 0) || "",
        Aa: !!K("INNERTUBE_USE_THIRD_PARTY_AUTH", !1),
        za: !!K("INNERTUBE_OMIT_API_KEY_WHEN_AUTH_HEADER_IS_PRESENT", !1),
        appInstallData: K("SERIALIZED_CLIENT_CONFIG_DATA", void 0)
    }
}

function Ne(a) {
    const b = {
        client: {
            hl: a.ka,
            gl: a.ja,
            clientName: a.wa,
            clientVersion: a.innertubeContextClientVersion,
            configInfo: a.W
        }
    };
    navigator.userAgent && (b.client.userAgent = String(navigator.userAgent));
    var c = t.devicePixelRatio;
    c && 1 != c && (b.client.screenDensityFloat = String(c));
    c = Sd();
    "" !== c && (b.client.experimentsToken = c);
    c = Td();
    0 < c.length && (b.request = {
        internalExperimentFlags: c
    });
    af(a, void 0, b);
    K("DELEGATED_SESSION_ID") && !L("pageid_as_header_web") && (b.user = {
        onBehalfOfUser: K("DELEGATED_SESSION_ID")
    });
    a = Object;
    c = a.assign;
    var d = b.client,
        e = K("DEVICE", "");
    const f = {};
    for (const [g, h] of Object.entries(le(e))) {
        e = g;
        const k = h;
        "cbrand" === e ? f.deviceMake = k : "cmodel" === e ? f.deviceModel = k : "cbr" === e ? f.browserName = k : "cbrver" === e ? f.browserVersion = k : "cos" === e ? f.osName = k : "cosver" === e ? f.osVersion = k : "cplatform" === e && (f.platform = k)
    }
    b.client = c.call(a, d, f);
    return b
}

function Ue(a) {
    const b = new gd,
        c = new $c;
    B(c, 1, a.ka);
    B(c, 2, a.ja);
    B(c, 16, a.xa);
    B(c, 17, a.innertubeContextClientVersion);
    if (a.W) {
        var d = a.W,
            e = new Yc;
        d.coldConfigData && B(e, 1, d.coldConfigData);
        d.appInstallData && B(e, 6, d.appInstallData);
        d.coldHashData && B(e, 3, d.coldHashData);
        d.hotHashData && B(e, 5, d.hotHashData);
        C(c, 62, e)
    }(d = t.devicePixelRatio) && 1 != d && B(c, 65, d);
    d = Sd();
    "" !== d && B(c, 54, d);
    d = Td();
    if (0 < d.length) {
        e = new bd;
        for (let f = 0; f < d.length; f++) {
            const g = new Xc;
            B(g, 1, d[f].key);
            g.setValue(d[f].value);
            sb(e, 15, Xc, g,
                void 0)
        }
        C(b, 5, e)
    }
    af(a, c);
    K("DELEGATED_SESSION_ID") && !L("pageid_as_header_web") && (a = new ed, B(a, 3, K("DELEGATED_SESSION_ID")));
    a = K("DEVICE", "");
    for (const [f, g] of Object.entries(le(a))) a = f, d = g, "cbrand" === a ? B(c, 12, d) : "cmodel" === a ? B(c, 13, d) : "cbr" === a ? B(c, 87, d) : "cbrver" === a ? B(c, 88, d) : "cos" === a ? B(c, 18, d) : "cosver" === a ? B(c, 19, d) : "cplatform" === a && B(c, 42, d);
    C(b, 1, c);
    return b
}

function af(a, b, c) {
    if (a.appInstallData)
        if (b) {
            let d;
            c = null != (d = ob(b, Yc, 62)) ? d : new Yc;
            B(c, 6, a.appInstallData);
            C(b, 62, c)
        } else c && (c.client.configInfo = c.client.configInfo || {}, c.client.configInfo.appInstallData = a.appInstallData)
}

function bf(a, b, c = {}) {
    let d = {};
    L("enable_web_eom_visitor_data") && K("EOM_VISITOR_DATA") ? d = {
        "X-Goog-EOM-Visitor-Id": K("EOM_VISITOR_DATA")
    } : d = {
        "X-Goog-Visitor-Id": c.visitorData || K("VISITOR_DATA", "")
    };
    if (b && b.includes("www.youtube-nocookie.com")) return d;
    (b = c.lb || K("AUTHORIZATION")) || (a ? b = `Bearer ${v("gapi.auth.getToken")().kb}` : b = lc());
    b && (d.Authorization = b, d["X-Goog-AuthUser"] = K("SESSION_INDEX", 0), L("pageid_as_header_web") && (d["X-Goog-PageId"] = K("DELEGATED_SESSION_ID")));
    return d
};
const cf = [];
let df, ef = !1;

function ff(a) {
    ef || (df ? df.handleError(a) : (cf.push({
        type: "ERROR",
        payload: a
    }), 10 < cf.length && cf.shift()))
}

function gf(a, b) {
    ef || (df ? df.O(a, b) : (cf.push({
        type: "EVENT",
        eventType: a,
        payload: b
    }), 10 < cf.length && cf.shift()))
};
var R = class extends Error {
    constructor(a, ...b) {
        super(a);
        this.args = [...b]
    }
};

function hf() {
    if (void 0 !== K("DATASYNC_ID", void 0)) return K("DATASYNC_ID", void 0);
    throw new R("Datasync ID not set", "unknown");
};

function jf(a) {
    if (0 <= a.indexOf(":")) throw Error("Database name cannot contain ':'");
}

function kf(a) {
    return a.substr(0, a.indexOf(":")) || a
};
const lf = {
        AUTH_INVALID: "No user identifier specified.",
        EXPLICIT_ABORT: "Transaction was explicitly aborted.",
        IDB_NOT_SUPPORTED: "IndexedDB is not supported.",
        MISSING_INDEX: "Index not created.",
        MISSING_OBJECT_STORES: "Object stores not created.",
        DB_DELETED_BY_MISSING_OBJECT_STORES: "Database is deleted because expected object stores were not created.",
        DB_REOPENED_BY_MISSING_OBJECT_STORES: "Database is reopened because expected object stores were not created.",
        UNKNOWN_ABORT: "Transaction was aborted for unknown reasons.",
        QUOTA_EXCEEDED: "The current transaction exceeded its quota limitations.",
        QUOTA_MAYBE_EXCEEDED: "The current transaction may have failed because of exceeding quota limitations.",
        EXECUTE_TRANSACTION_ON_CLOSED_DB: "Can't start a transaction on a closed database",
        INCOMPATIBLE_DB_VERSION: "The binary is incompatible with the database version"
    },
    mf = {
        AUTH_INVALID: "ERROR",
        EXECUTE_TRANSACTION_ON_CLOSED_DB: "WARNING",
        EXPLICIT_ABORT: "IGNORED",
        IDB_NOT_SUPPORTED: "ERROR",
        MISSING_INDEX: "WARNING",
        MISSING_OBJECT_STORES: "ERROR",
        DB_DELETED_BY_MISSING_OBJECT_STORES: "WARNING",
        DB_REOPENED_BY_MISSING_OBJECT_STORES: "WARNING",
        QUOTA_EXCEEDED: "WARNING",
        QUOTA_MAYBE_EXCEEDED: "WARNING",
        UNKNOWN_ABORT: "WARNING",
        INCOMPATIBLE_DB_VERSION: "WARNING"
    },
    nf = {
        AUTH_INVALID: !1,
        EXECUTE_TRANSACTION_ON_CLOSED_DB: !1,
        EXPLICIT_ABORT: !1,
        IDB_NOT_SUPPORTED: !1,
        MISSING_INDEX: !1,
        MISSING_OBJECT_STORES: !1,
        DB_DELETED_BY_MISSING_OBJECT_STORES: !1,
        DB_REOPENED_BY_MISSING_OBJECT_STORES: !1,
        QUOTA_EXCEEDED: !1,
        QUOTA_MAYBE_EXCEEDED: !0,
        UNKNOWN_ABORT: !0,
        INCOMPATIBLE_DB_VERSION: !1
    };
var S = class extends R {
        constructor(a, b = {}, c = lf[a], d = mf[a], e = nf[a]) {
            super(c, Object.assign({}, {
                name: "YtIdbKnownError",
                isSw: void 0 === self.document,
                isIframe: self !== self.top,
                type: a
            }, b));
            this.type = a;
            this.message = c;
            this.level = d;
            this.h = e;
            Object.setPrototypeOf(this, S.prototype)
        }
    },
    of = class extends S {
        constructor(a, b) {
            super("MISSING_OBJECT_STORES", {
                expectedObjectStores: b,
                foundObjectStores: a
            }, lf.MISSING_OBJECT_STORES);
            Object.setPrototypeOf(this, of .prototype)
        }
    },
    pf = class extends Error {
        constructor(a, b) {
            super();
            this.index =
                a;
            this.objectStore = b;
            Object.setPrototypeOf(this, pf.prototype)
        }
    };
const qf = ["The database connection is closing", "Can't start a transaction on a closed database", "A mutation operation was attempted on a database that did not allow mutations"];

function rf(a, b, c, d) {
    b = kf(b);
    let e;
    e = a instanceof Error ? a : Error(`Unexpected error: ${a}`);
    if (e instanceof S) return e;
    a = {
        objectStoreNames: c,
        dbName: b,
        dbVersion: d
    };
    if ("QuotaExceededError" === e.name) return new S("QUOTA_EXCEEDED", a);
    if (Ja && "UnknownError" === e.name) return new S("QUOTA_MAYBE_EXCEEDED", a);
    if (e instanceof pf) return new S("MISSING_INDEX", Object.assign({}, a, {
        objectStore: e.objectStore,
        index: e.index
    }));
    if ("InvalidStateError" === e.name && qf.some(f => e.message.includes(f))) return new S("EXECUTE_TRANSACTION_ON_CLOSED_DB",
        a);
    if ("AbortError" === e.name) return new S("UNKNOWN_ABORT", a, e.message);
    e.args = [Object.assign({}, a, {
        name: "IdbError",
        xb: e.name
    })];
    e.level = "WARNING";
    return e
}

function sf(a, b, c) {
    return new S("IDB_NOT_SUPPORTED", {
        context: {
            caller: a,
            publicName: b,
            version: c,
            hasSucceededOnce: void 0
        }
    })
};

function uf(a) {
    if (!a) throw Error();
    throw a;
}

function vf(a) {
    return a
}
var wf = class {
    constructor(a) {
        this.h = a
    }
};

function xf(a) {
    return new T(new wf((b, c) => {
        a instanceof T ? a.then(b, c) : b(a)
    }))
}

function yf(a, b, c, d, e) {
    try {
        if ("FULFILLED" !== a.state.status) throw Error("calling handleResolve before the promise is fulfilled.");
        const f = c(a.state.value);
        f instanceof T ? zf(a, b, f, d, e) : d(f)
    } catch (f) {
        e(f)
    }
}

function Af(a, b, c, d, e) {
    try {
        if ("REJECTED" !== a.state.status) throw Error("calling handleReject before the promise is rejected.");
        const f = c(a.state.reason);
        f instanceof T ? zf(a, b, f, d, e) : d(f)
    } catch (f) {
        e(f)
    }
}

function zf(a, b, c, d, e) {
    b === c ? e(new TypeError("Circular promise chain detected.")) : c.then(f => {
        f instanceof T ? zf(a, b, f, d, e) : d(f)
    }, f => {
        e(f)
    })
}
var T = class {
    constructor(a) {
        this.state = {
            status: "PENDING"
        };
        this.h = [];
        this.onRejected = [];
        a = a.h;
        const b = d => {
                if ("PENDING" === this.state.status) {
                    this.state = {
                        status: "FULFILLED",
                        value: d
                    };
                    for (const e of this.h) e()
                }
            },
            c = d => {
                if ("PENDING" === this.state.status) {
                    this.state = {
                        status: "REJECTED",
                        reason: d
                    };
                    for (const e of this.onRejected) e()
                }
            };
        try {
            a(b, c)
        } catch (d) {
            c(d)
        }
    }
    static all(a) {
        return new T(new wf((b, c) => {
            const d = [];
            let e = a.length;
            0 === e && b(d);
            for (let f = 0; f < a.length; ++f) xf(a[f]).then(g => {
                d[f] = g;
                e--;
                0 === e && b(d)
            }).catch(g => {
                c(g)
            })
        }))
    }
    static reject(a) {
        return new T(new wf((b, c) => {
            c(a)
        }))
    }
    then(a, b) {
        const c = null != a ? a : vf,
            d = null != b ? b : uf;
        return new T(new wf((e, f) => {
            "PENDING" === this.state.status ? (this.h.push(() => {
                yf(this, this, c, e, f)
            }), this.onRejected.push(() => {
                Af(this, this, d, e, f)
            })) : "FULFILLED" === this.state.status ? yf(this, this, c, e, f) : "REJECTED" === this.state.status && Af(this, this, d, e, f)
        }))
    } catch (a) {
        return this.then(void 0, a)
    }
};

function Bf(a, b, c) {
    const d = () => {
            try {
                a.removeEventListener("success", e), a.removeEventListener("error", f)
            } catch (g) {}
        },
        e = () => {
            b(a.result);
            d()
        },
        f = () => {
            c(a.error);
            d()
        };
    a.addEventListener("success", e);
    a.addEventListener("error", f)
}

function Cf(a) {
    return new Promise((b, c) => {
        Bf(a, b, c)
    })
}

function U(a) {
    return new T(new wf((b, c) => {
        Bf(a, b, c)
    }))
};

function Df(a, b) {
    return new T(new wf((c, d) => {
        const e = () => {
            const f = a ? b(a) : null;
            f ? f.then(g => {
                a = g;
                e()
            }, d) : c()
        };
        e()
    }))
};

function V(a, b, c, d) {
    return r(function*() {
        const e = {
            mode: "readonly",
            H: !1,
            tag: "IDB_TRANSACTION_TAG_UNKNOWN"
        };
        "string" === typeof c ? e.mode = c : Object.assign(e, c);
        a.transactionCount++;
        const f = e.H ? 3 : 1;
        let g = 0,
            h;
        for (; !h;) {
            g++;
            const l = Math.round(M());
            try {
                const m = a.h.transaction(b, e.mode);
                var k = d;
                const p = new Ef(m),
                    u = yield Ff(p, k), n = Math.round(M());
                Gf(a, l, n, g, void 0, b.join(), e);
                return u
            } catch (m) {
                k = Math.round(M());
                const p = rf(m, a.h.name, b.join(), a.h.version);
                if (p instanceof S && !p.h || g >= f) Gf(a, l, k, g, p, b.join(), e),
                    h = p
            }
        }
        return Promise.reject(h)
    })
}

function Hf(a, b, c) {
    a = a.h.createObjectStore(b, c);
    return new If(a)
}

function Jf(a, b, c, d) {
    return V(a, [b], {
        mode: "readwrite",
        H: !0
    }, e => {
        e = e.objectStore(b);
        return U(e.h.put(c, d))
    })
}

function Gf(a, b, c, d, e, f, g) {
    b = c - b;
    e ? (e instanceof S && ("QUOTA_EXCEEDED" === e.type || "QUOTA_MAYBE_EXCEEDED" === e.type) && gf("QUOTA_EXCEEDED", {
        dbName: kf(a.h.name),
        objectStoreNames: f,
        transactionCount: a.transactionCount,
        transactionMode: g.mode
    }), e instanceof S && "UNKNOWN_ABORT" === e.type && (c -= a.j, 0 > c && c >= Math.pow(2, 31) && (c = 0), gf("TRANSACTION_UNEXPECTEDLY_ABORTED", {
        objectStoreNames: f,
        transactionDuration: b,
        transactionCount: a.transactionCount,
        dbDuration: c
    }), a.i = !0), Kf(a, !1, d, f, b, g.tag), ff(e)) : Kf(a, !0, d, f, b, g.tag)
}

function Kf(a, b, c, d, e, f = "IDB_TRANSACTION_TAG_UNKNOWN") {
    gf("TRANSACTION_ENDED", {
        objectStoreNames: d,
        connectionHasUnknownAbortedTransaction: a.i,
        duration: e,
        isSuccessful: b,
        tryCount: c,
        tag: f
    })
}
var Lf = class {
    constructor(a, b) {
        this.h = a;
        this.options = b;
        this.transactionCount = 0;
        this.j = Math.round(M());
        this.i = !1
    }
    add(a, b, c) {
        return V(this, [a], {
            mode: "readwrite",
            H: !0
        }, d => d.objectStore(a).add(b, c))
    }
    clear(a) {
        return V(this, [a], {
            mode: "readwrite",
            H: !0
        }, b => b.objectStore(a).clear())
    }
    close() {
        this.h.close();
        let a;
        (null == (a = this.options) ? 0 : a.closed) && this.options.closed()
    }
    count(a, b) {
        return V(this, [a], {
            mode: "readonly",
            H: !0
        }, c => c.objectStore(a).count(b))
    }
    delete(a, b) {
        return V(this, [a], {
            mode: "readwrite",
            H: !0
        }, c => c.objectStore(a).delete(b))
    }
    get(a, b) {
        return V(this, [a], {
            mode: "readonly",
            H: !0
        }, c => c.objectStore(a).get(b))
    }
    objectStoreNames() {
        return Array.from(this.h.objectStoreNames)
    }
    getName() {
        return this.h.name
    }
};

function Mf(a, b, c) {
    a = a.h.openCursor(b.query, b.direction);
    return Nf(a).then(d => Df(d, c))
}

function Of(a, b) {
    return Mf(a, {
        query: b
    }, c => c.delete().then(() => c.continue())).then(() => {})
}
var If = class {
    constructor(a) {
        this.h = a
    }
    add(a, b) {
        return U(this.h.add(a, b))
    }
    autoIncrement() {
        return this.h.autoIncrement
    }
    clear() {
        return U(this.h.clear()).then(() => {})
    }
    count(a) {
        return U(this.h.count(a))
    }
    delete(a) {
        return a instanceof IDBKeyRange ? Of(this, a) : U(this.h.delete(a))
    }
    get(a) {
        return U(this.h.get(a))
    }
    index(a) {
        try {
            return new Pf(this.h.index(a))
        } catch (b) {
            if (b instanceof Error && "NotFoundError" === b.name) throw new pf(a, this.h.name);
            throw b;
        }
    }
    getName() {
        return this.h.name
    }
    keyPath() {
        return this.h.keyPath
    }
};

function Ff(a, b) {
    const c = new Promise((d, e) => {
        try {
            b(a).then(f => {
                d(f)
            }).catch(e)
        } catch (f) {
            e(f), a.abort()
        }
    });
    return Promise.all([c, a.done]).then(([d]) => d)
}
var Ef = class {
    constructor(a) {
        this.h = a;
        this.j = new Map;
        this.i = !1;
        this.done = new Promise((b, c) => {
            this.h.addEventListener("complete", () => {
                b()
            });
            this.h.addEventListener("error", d => {
                d.currentTarget === d.target && c(this.h.error)
            });
            this.h.addEventListener("abort", () => {
                var d = this.h.error;
                if (d) c(d);
                else if (!this.i) {
                    d = S;
                    var e = this.h.objectStoreNames;
                    const f = [];
                    for (let g = 0; g < e.length; g++) {
                        const h = e.item(g);
                        if (null === h) throw Error("Invariant: item in DOMStringList is null");
                        f.push(h)
                    }
                    d = new d("UNKNOWN_ABORT", {
                        objectStoreNames: f.join(),
                        dbName: this.h.db.name,
                        mode: this.h.mode
                    });
                    c(d)
                }
            })
        })
    }
    abort() {
        this.h.abort();
        this.i = !0;
        throw new S("EXPLICIT_ABORT");
    }
    objectStore(a) {
        a = this.h.objectStore(a);
        let b = this.j.get(a);
        b || (b = new If(a), this.j.set(a, b));
        return b
    }
};

function Qf(a, b, c) {
    const {
        query: d = null,
        direction: e = "next"
    } = b;
    a = a.h.openCursor(d, e);
    return Nf(a).then(f => Df(f, c))
}
var Pf = class {
    constructor(a) {
        this.h = a
    }
    count(a) {
        return U(this.h.count(a))
    }
    delete(a) {
        return Qf(this, {
            query: a
        }, b => b.delete().then(() => b.continue()))
    }
    get(a) {
        return U(this.h.get(a))
    }
    getKey(a) {
        return U(this.h.getKey(a))
    }
    keyPath() {
        return this.h.keyPath
    }
    unique() {
        return this.h.unique
    }
};

function Nf(a) {
    return U(a).then(b => b ? new Rf(a, b) : null)
}
var Rf = class {
    constructor(a, b) {
        this.request = a;
        this.cursor = b
    }
    advance(a) {
        this.cursor.advance(a);
        return Nf(this.request)
    }
    continue (a) {
        this.cursor.continue(a);
        return Nf(this.request)
    }
    delete() {
        return U(this.cursor.delete()).then(() => {})
    }
    getKey() {
        return this.cursor.key
    }
    ia() {
        return this.cursor.value
    }
    update(a) {
        return U(this.cursor.update(a))
    }
};

function Sf(a, b, c) {
    return new Promise((d, e) => {
        let f;
        f = void 0 !== b ? self.indexedDB.open(a, b) : self.indexedDB.open(a);
        const g = c.blocked,
            h = c.blocking,
            k = c.Ga,
            l = c.upgrade,
            m = c.closed;
        let p;
        const u = () => {
            p || (p = new Lf(f.result, {
                closed: m
            }));
            return p
        };
        f.addEventListener("upgradeneeded", n => {
            try {
                if (null === n.newVersion) throw Error("Invariant: newVersion on IDbVersionChangeEvent is null");
                if (null === f.transaction) throw Error("Invariant: transaction on IDbOpenDbRequest is null");
                n.dataLoss && "none" !== n.dataLoss && gf("IDB_DATA_CORRUPTED", {
                    reason: n.dataLossMessage || "unknown reason",
                    dbName: kf(a)
                });
                const x = u(),
                    G = new Ef(f.transaction);
                l && l(x, H => n.oldVersion < H && n.newVersion >= H, G);
                G.done.catch(H => {
                    e(H)
                })
            } catch (x) {
                e(x)
            }
        });
        f.addEventListener("success", () => {
            const n = f.result;
            h && n.addEventListener("versionchange", () => {
                h(u())
            });
            n.addEventListener("close", () => {
                gf("IDB_UNEXPECTEDLY_CLOSED", {
                    dbName: kf(a),
                    dbVersion: n.version
                });
                k && k()
            });
            d(u())
        });
        f.addEventListener("error", () => {
            e(f.error)
        });
        g && f.addEventListener("blocked", () => {
            g()
        })
    })
}

function Tf(a, b, c = {}) {
    return Sf(a, b, c)
}

function Uf(a, b = {}) {
    return r(function*() {
        try {
            const c = self.indexedDB.deleteDatabase(a),
                d = b.blocked;
            d && c.addEventListener("blocked", () => {
                d()
            });
            yield Cf(c)
        } catch (c) {
            throw rf(c, a, "", -1);
        }
    })
};

function Vf(a) {
    return new Promise(b => {
        ae(() => {
            b()
        }, a)
    })
}

function Wf(a, b) {
    return new S("INCOMPATIBLE_DB_VERSION", {
        dbName: a.name,
        oldVersion: a.options.version,
        newVersion: b
    })
}

function Xf(a) {
    if (!a.l) throw Wf(a);
    if (a.h) return a.h;
    let b;
    const c = () => {
            a.h === b && (a.h = void 0)
        },
        d = {
            blocking: f => {
                f.close()
            },
            closed: c,
            Ga: c,
            upgrade: a.options.upgrade
        },
        e = () => r(function*() {
            var f, g = null != (f = Error().stack) ? f : "";
            try {
                const k = yield a.j(a.name, a.options.version, d);
                f = k;
                var h = a.options;
                const l = [];
                for (const m of Object.keys(h.L)) {
                    const {
                        N: p,
                        Bb: u = Number.MAX_VALUE
                    } = h.L[m];
                    !(f.h.version >= p) || f.h.version >= u || f.h.objectStoreNames.contains(m) || l.push(m)
                }
                if (0 !== l.length) {
                    const m = Object.keys(a.options.L),
                        p = k.objectStoreNames();
                    if (a.o < Rd("ytidb_reopen_db_retries", 0)) return a.o++, k.close(), ff(new S("DB_REOPENED_BY_MISSING_OBJECT_STORES", {
                        dbName: a.name,
                        expectedObjectStores: m,
                        foundObjectStores: p
                    })), e();
                    if (a.m < Rd("ytidb_remake_db_retries", 1)) return a.m++, L("ytidb_remake_db_enable_backoff_delay") && (yield Vf(a.i), a.i *= 2), yield a.delete(), ff(new S("DB_DELETED_BY_MISSING_OBJECT_STORES", {
                        dbName: a.name,
                        expectedObjectStores: m,
                        foundObjectStores: p
                    })), e();
                    throw new of (p, m);
                }
                return k
            } catch (k) {
                if (k instanceof DOMException ? "VersionError" === k.name : "DOMError" in self && k instanceof DOMError ? "VersionError" === k.name : k instanceof Object && "message" in k &&
                    "An attempt was made to open a database using a lower version than the existing version." === k.message) {
                    g = yield a.j(a.name, void 0, Object.assign({}, d, {
                        upgrade: void 0
                    }));
                    h = g.h.version;
                    if (void 0 !== a.options.version && h > a.options.version + 1) throw g.close(), a.l = !1, Wf(a, h);
                    return g
                }
                c();
                k instanceof Error && !L("ytidb_async_stack_killswitch") && (k.stack = `${k.stack}\n${g.substring(g.indexOf("\n")+1)}`);
                let l;
                throw rf(k, a.name, "", null != (l = a.options.version) ? l : -1);
            }
        });
    b = e();
    a.h = b;
    return a.h
}

function Yf(a, b) {
    if (!b) throw sf("openWithToken", kf(a.name));
    return Xf(a)
}
var Zf = class {
    constructor(a, b) {
        this.name = a;
        this.options = b;
        this.l = !0;
        this.o = this.m = 0;
        this.i = 500
    }
    j(a, b, c = {}) {
        return Tf(a, b, c)
    }
    delete(a = {}) {
        return Uf(this.name, a)
    }
};
const $f = new Zf("YtIdbMeta", {
    L: {
        databases: {
            N: 1
        }
    },
    upgrade(a, b) {
        b(1) && Hf(a, "databases", {
            keyPath: "actualName"
        })
    }
});

function ag(a, b) {
    return r(function*() {
        return V(yield Yf($f, b), ["databases"], {
            H: !0,
            mode: "readwrite"
        }, c => {
            const d = c.objectStore("databases");
            return d.get(a.actualName).then(e => {
                if (e ? a.actualName !== e.actualName || a.publicName !== e.publicName || a.userIdentifier !== e.userIdentifier : 1) return U(d.h.put(a, void 0)).then(() => {})
            })
        })
    })
}

function bg(a, b) {
    return r(function*() {
        if (a) return (yield Yf($f, b)).delete("databases", a)
    })
};
let cg;
const dg = new class {
    constructor() {}
}(new class {
    constructor() {}
});

function eg() {
    return r(function*() {
        return !0
    })
}

function fg() {
    if (void 0 !== cg) return cg;
    ef = !0;
    return cg = eg().then(a => {
        ef = !1;
        return a
    })
}

function gg() {
    const a = v("ytglobal.idbToken_") || void 0;
    return a ? Promise.resolve(a) : fg().then(b => {
        (b = b ? dg : void 0) && w("ytglobal.idbToken_", b);
        return b
    })
};
new Dc;

function hg(a) {
    try {
        hf();
        var b = !0
    } catch (c) {
        b = !1
    }
    if (!b) throw a = new S("AUTH_INVALID", {
        dbName: a
    }), ff(a), a;
    b = hf();
    return {
        actualName: `${a}:${b}`,
        publicName: a,
        userIdentifier: b
    }
}

function ig(a, b, c, d) {
    return r(function*() {
        var e, f = null != (e = Error().stack) ? e : "";
        e = yield gg();
        if (!e) throw e = sf("openDbImpl", a, b), L("ytidb_async_stack_killswitch") || (e.stack = `${e.stack}\n${f.substring(f.indexOf("\n")+1)}`), ff(e), e;
        jf(a);
        f = c ? {
            actualName: a,
            publicName: a,
            userIdentifier: void 0
        } : hg(a);
        try {
            return yield ag(f, e), yield Tf(f.actualName, b, d)
        } catch (g) {
            try {
                yield bg(f.actualName, e)
            } catch (h) {}
            throw g;
        }
    })
}

function jg(a, b, c = {}) {
    return ig(a, b, !1, c)
}

function kg(a, b, c = {}) {
    return ig(a, b, !0, c)
}

function lg(a, b = {}) {
    return r(function*() {
        const c = yield gg();
        if (c) {
            jf(a);
            var d = hg(a);
            yield Uf(d.actualName, b);
            yield bg(d.actualName, c)
        }
    })
}

function mg(a, b = {}) {
    return r(function*() {
        const c = yield gg();
        c && (jf(a), yield Uf(a, b), yield bg(a, c))
    })
};

function ng(a) {
    this.version = 1;
    this.args = a
};

function og() {
    var a = pg;
    this.topic = "screen-created";
    this.h = a
}
og.prototype.toString = function() {
    return this.topic
};
const qg = v("ytPubsub2Pubsub2Instance") || new F;
F.prototype.subscribe = F.prototype.subscribe;
F.prototype.unsubscribeByKey = F.prototype.ca;
F.prototype.publish = F.prototype.Z;
F.prototype.clear = F.prototype.clear;
w("ytPubsub2Pubsub2Instance", qg);
const rg = v("ytPubsub2Pubsub2SubscribedKeys") || {};
w("ytPubsub2Pubsub2SubscribedKeys", rg);
const sg = v("ytPubsub2Pubsub2TopicToKeys") || {};
w("ytPubsub2Pubsub2TopicToKeys", sg);
const tg = v("ytPubsub2Pubsub2IsAsync") || {};
w("ytPubsub2Pubsub2IsAsync", tg);
w("ytPubsub2Pubsub2SkipSubKey", null);

function ug(a) {
    var b = vg;
    const c = wg();
    c && c.publish.call(c, b.toString(), b, a)
}

function xg(a) {
    var b = vg;
    const c = wg();
    if (!c) return 0;
    const d = c.subscribe(b.toString(), (e, f) => {
        var g = v("ytPubsub2Pubsub2SkipSubKey");
        g && g == d || (g = () => {
            if (rg[d]) try {
                if (f && b instanceof og && b != e) try {
                    var h = b.h,
                        k = f;
                    if (!k.args || !k.version) throw Error("yt.pubsub2.Data.deserialize(): serializedData is incomplete.");
                    try {
                        if (!h.oa) {
                            const n = new h;
                            h.oa = n.version
                        }
                        var l = h.oa
                    } catch (n) {}
                    if (!l || k.version != l) throw Error("yt.pubsub2.Data.deserialize(): serializedData version is incompatible.");
                    try {
                        l = Reflect;
                        var m = l.construct; {
                            var p = k.args;
                            const n = p.length;
                            if (0 < n) {
                                const x = Array(n);
                                for (k = 0; k < n; k++) x[k] = p[k];
                                var u = x
                            } else u = []
                        }
                        f = m.call(l, h, u)
                    } catch (n) {
                        throw n.message = "yt.pubsub2.Data.deserialize(): " + n.message, n;
                    }
                } catch (n) {
                    throw n.message = "yt.pubsub2.pubsub2 cross-binary conversion error for " + b.toString() + ": " + n.message, n;
                }
                a.call(window, f)
            } catch (n) {
                Yd(n)
            }
        }, tg[b.toString()] ? v("yt.scheduler.instance") ? ee.h(g) : $d(g, 0) : g())
    });
    rg[d] = !0;
    sg[b.toString()] || (sg[b.toString()] = []);
    sg[b.toString()].push(d);
    return d
}

function yg() {
    var a = zg;
    const b = xg(function(c) {
        a.apply(void 0, arguments);
        Ag(b)
    });
    return b
}

function Ag(a) {
    const b = wg();
    b && ("number" === typeof a && (a = [a]), oa(a, c => {
        b.unsubscribeByKey(c);
        delete rg[c]
    }))
}

function wg() {
    return v("ytPubsub2Pubsub2Instance")
};

function Bg(a, b) {
    let c;
    return () => {
        c || (c = new Cg(a, b));
        return c
    }
}
var Cg = class extends Zf {
    constructor(a, b) {
        super(a, b);
        this.options = b;
        jf(a)
    }
    j(a, b, c = {}) {
        return (this.options.aa ? kg : jg)(a, b, Object.assign({}, c))
    }
    delete(a = {}) {
        return (this.options.aa ? mg : lg)(this.name, a)
    }
};
const Dg = ["client.name", "client.version"];

function Eg(a) {
    if (!a.errorMetadata || !a.errorMetadata.kvPairs) return a;
    a.errorMetadata.kvPairs = a.errorMetadata.kvPairs.filter(b => b.key ? Dg.includes(b.key) : !1);
    return a
};
var Fg;
Fg = Bg("ServiceWorkerLogsDatabase", {
    L: {
        SWHealthLog: {
            N: 1
        }
    },
    aa: !0,
    upgrade: (a, b) => {
        b(1) && Hf(a, "SWHealthLog", {
            keyPath: "id",
            autoIncrement: !0
        }).h.createIndex("swHealthNewRequest", ["interface", "timestamp"], {
            unique: !1
        })
    },
    version: 1
});

function Gg(a, b) {
    return r(function*() {
        var c = yield Yf(Fg(), b), d = K("INNERTUBE_CONTEXT_CLIENT_NAME", 0);
        const e = Object.assign({}, a);
        e.clientError && (e.clientError = Eg(e.clientError));
        e.interface = d;
        return Jf(c, "SWHealthLog", e)
    })
};
const Hg = t.ytNetworklessLoggingInitializationOptions || {
    isNwlInitialized: !1,
    potentialEsfErrorCounter: 0
};
w("ytNetworklessLoggingInitializationOptions", Hg);

function Se(a, b, c) {
    !K("VISITOR_DATA") && .01 > Math.random() && Zd(new R("Missing VISITOR_DATA when sending innertube request.", "log_event", b, c));
    if (!a.isReady()) throw a = new R("innertube xhrclient not ready", "log_event", b, c), Yd(a), a;
    const d = {
        headers: c.headers || {},
        method: "POST",
        postParams: b,
        postBody: c.postBody,
        postBodyFormat: c.postBodyFormat || "JSON",
        onTimeout: () => {
            c.onTimeout()
        },
        onFetchTimeout: c.onTimeout,
        onSuccess: (m, p) => {
            if (c.onSuccess) c.onSuccess(p)
        },
        onFetchSuccess: m => {
            if (c.onSuccess) c.onSuccess(m)
        },
        onError: (m, p) => {
            if (c.onError) c.onError(p)
        },
        onFetchError: m => {
            if (c.onError) c.onError(m)
        },
        timeout: c.timeout,
        withCredentials: !0
    };
    d.headers["Content-Type"] || (d.headers["Content-Type"] = "application/json");
    b = "";
    var e = a.config_.ya;
    e && (b = e);
    e = bf(a.config_.Aa || !1, b, c);
    Object.assign(d.headers, e);
    (e = d.headers.Authorization) && !b && (d.headers["x-origin"] = window.location.origin);
    const f = `/${"youtubei"}/${a.config_.innertubeApiVersion}/${"log_event"}`;
    let g = {
            alt: "json"
        },
        h = a.config_.za && e;
    h = h && e.startsWith("Bearer");
    h || (g.key = a.config_.innertubeApiKey);
    const k = me(`${b}${f}`, g || {}, !0),
        l = () => {
            try {
                pe(k,
                    d)
            } catch (m) {
                if ("InvalidAccessError" == m.name) Zd(Error("An extension is blocking network request."));
                else throw m;
            }
        };
    !L("use_new_nwl") && v("ytNetworklessLoggingInitializationOptions") && Hg.isNwlInitialized ? fg().then(m => {
        l(m)
    }) : l(!1)
}
class Ig {
    constructor(a) {
        this.config_ = null;
        a ? this.config_ = a : $e() && (this.config_ = Oe())
    }
    isReady() {
        !this.config_ && $e() && (this.config_ = Oe());
        return !!this.config_
    }
};
let Jg = Ig;

function W(a, b, c = {}) {
    let d = Jg;
    K("ytLoggingEventsDefaultDisabled", !1) && Jg == Ig && (d = null);
    O(a, b, d, c)
};
let Kg = Date.now().toString();
var Lg;
let Mg = t.ytLoggingDocDocumentNonce_;
if (!Mg) {
    var Ng;
    a: {
        if (window.crypto && window.crypto.getRandomValues) try {
            const d = Array(16),
                e = new Uint8Array(16);
            window.crypto.getRandomValues(e);
            for (let f = 0; f < d.length; f++) d[f] = e[f];
            Ng = d;
            break a
        } catch (d) {}
        const c = Array(16);
        for (let d = 0; 16 > d; d++) {
            const e = Date.now();
            for (let f = 0; f < e % 23; f++) c[d] = Math.random();
            c[d] = Math.floor(256 * Math.random())
        }
        if (Kg) {
            let d = 1;
            for (let e = 0; e < Kg.length; e++) c[d % 16] = c[d % 16] ^ c[(d - 1) % 16] / 4 ^ Kg.charCodeAt(e), d++
        }
        Ng = c
    }
    const a = Ng,
        b = [];
    for (let c = 0; c < a.length; c++) b.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(a[c] &
        63));
    Mg = b.join("")
}
Lg = Mg;
let Og = Ig;
var Pg = {
    Ma: 0,
    Ka: 1,
    La: 2,
    fb: 3,
    Na: 4,
    jb: 5,
    gb: 6,
    ib: 7,
    hb: 8,
    0: "DEFAULT",
    1: "CHAT",
    2: "CONVERSATIONS",
    3: "MINIPLAYER",
    4: "DIALOG",
    5: "VOZ",
    6: "MUSIC_WATCH_TABS",
    7: "SHARE",
    8: "PUSH_NOTIFICATIONS"
};
let Qg = 1;

function Rg(a) {
    const b = Qg++;
    return new Sg({
        veType: a,
        veCounter: b,
        elementIndex: void 0,
        dataElement: void 0,
        youtubeData: void 0,
        jspbYoutubeData: void 0
    })
}
var Sg = class {
    constructor(a) {
        this.h = a
    }
    getAsJson() {
        const a = {};
        void 0 !== this.h.trackingParams ? a.trackingParams = this.h.trackingParams : (a.veType = this.h.veType, void 0 !== this.h.veCounter && (a.veCounter = this.h.veCounter), void 0 !== this.h.elementIndex && (a.elementIndex = this.h.elementIndex));
        void 0 !== this.h.dataElement && (a.dataElement = this.h.dataElement.getAsJson());
        void 0 !== this.h.youtubeData && (a.youtubeData = this.h.youtubeData);
        return a
    }
    getAsJspb() {
        const a = new hd;
        void 0 !== this.h.trackingParams ? B(a, 1, this.h.trackingParams) :
            (void 0 !== this.h.veType && B(a, 2, this.h.veType), void 0 !== this.h.veCounter && B(a, 6, this.h.veCounter), void 0 !== this.h.elementIndex && B(a, 3, this.h.elementIndex));
        if (void 0 !== this.h.dataElement) {
            var b = this.h.dataElement.getAsJspb();
            C(a, 7, b)
        }
        void 0 !== this.h.youtubeData && C(a, 8, this.h.jspbYoutubeData);
        return a
    }
    toString() {
        return JSON.stringify(this.getAsJson())
    }
    isClientVe() {
        return !this.h.trackingParams && !!this.h.veType
    }
};

function Tg(a = 0) {
    return 0 == a ? "client-screen-nonce" : `${"client-screen-nonce"}.${a}`
}

function Ug(a = 0) {
    return 0 == a ? "ROOT_VE_TYPE" : `${"ROOT_VE_TYPE"}.${a}`
}

function Vg(a = 0) {
    return K(Ug(a), void 0)
}

function Wg(a = 0) {
    return (a = Vg(a)) ? new Sg({
        veType: a,
        youtubeData: void 0,
        jspbYoutubeData: void 0
    }) : null
}

function Xg() {
    let a = K("csn-to-ctt-auth-info");
    a || (a = {}, J("csn-to-ctt-auth-info", a));
    return a
}

function X(a = 0) {
    let b = K(Tg(a));
    if (!b && !K("USE_CSN_FALLBACK", !0)) return null;
    b || !L("use_undefined_csn_any_layer") && 0 != a || (b = "UNDEFINED_CSN");
    return b ? b : null
}

function Yg(a, b, c) {
    const d = Xg();
    (c = X(c)) && delete d[c];
    b && (d[a] = b)
}

function Zg(a) {
    return Xg()[a]
}

function $g(a, b, c = 0, d) {
    if (a !== K(Tg(c)) || b !== K(Ug(c))) Yg(a, d, c), J(Tg(c), a), J(Ug(c), b), b = () => {
        setTimeout(() => {
            if (a) {
                const e = {
                    clientDocumentNonce: Lg,
                    clientScreenNonce: a
                };
                L("use_default_heartbeat_client") ? W("foregroundHeartbeatScreenAssociated", e) : O("foregroundHeartbeatScreenAssociated", e, Og)
            }
        }, 0)
    }, "requestAnimationFrame" in window ? window.requestAnimationFrame(b) : b()
};
const ah = [{
    Y: a => `Cannot read property '${a.key}'`,
    S: {
        Error: [{
            v: /(Permission denied) to access property "([^']+)"/,
            groups: ["reason", "key"]
        }],
        TypeError: [{
            v: /Cannot read property '([^']+)' of (null|undefined)/,
            groups: ["key", "value"]
        }, {
            v: /\u65e0\u6cd5\u83b7\u53d6\u672a\u5b9a\u4e49\u6216 (null|undefined) \u5f15\u7528\u7684\u5c5e\u6027\u201c([^\u201d]+)\u201d/,
            groups: ["value", "key"]
        }, {
            v: /\uc815\uc758\ub418\uc9c0 \uc54a\uc74c \ub610\ub294 (null|undefined) \ucc38\uc870\uc778 '([^']+)' \uc18d\uc131\uc744 \uac00\uc838\uc62c \uc218 \uc5c6\uc2b5\ub2c8\ub2e4./,
            groups: ["value", "key"]
        }, {
            v: /No se puede obtener la propiedad '([^']+)' de referencia nula o sin definir/,
            groups: ["key"]
        }, {
            v: /Unable to get property '([^']+)' of (undefined or null) reference/,
            groups: ["key", "value"]
        }, {
            v: /(null) is not an object \(evaluating '(?:([^.]+)\.)?([^']+)'\)/,
            groups: ["value", "base", "key"]
        }]
    }
}, {
    Y: a => `Cannot call '${a.key}'`,
    S: {
        TypeError: [{
            v: /(?:([^ ]+)?\.)?([^ ]+) is not a function/,
            groups: ["base", "key"]
        }, {
            v: /([^ ]+) called on (null or undefined)/,
            groups: ["key", "value"]
        }, {
            v: /Object (.*) has no method '([^ ]+)'/,
            groups: ["base", "key"]
        }, {
            v: /Object doesn't support property or method '([^ ]+)'/,
            groups: ["key"]
        }, {
            v: /\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u306f '([^']+)' \u30d7\u30ed\u30d1\u30c6\u30a3\u307e\u305f\u306f\u30e1\u30bd\u30c3\u30c9\u3092\u30b5\u30dd\u30fc\u30c8\u3057\u3066\u3044\u307e\u305b\u3093/,
            groups: ["key"]
        }, {
            v: /\uac1c\uccb4\uac00 '([^']+)' \uc18d\uc131\uc774\ub098 \uba54\uc11c\ub4dc\ub97c \uc9c0\uc6d0\ud558\uc9c0 \uc54a\uc2b5\ub2c8\ub2e4./,
            groups: ["key"]
        }]
    }
}, {
    Y: a => `${a.key} is not defined`,
    S: {
        ReferenceError: [{
            v: /(.*) is not defined/,
            groups: ["key"]
        }, {
            v: /Can't find variable: (.*)/,
            groups: ["key"]
        }]
    }
}];
var ch = {
    G: [],
    D: [{
        pa: bh,
        weight: 500
    }]
};

function bh(a) {
    if ("JavaException" === a.name) return !0;
    a = a.stack;
    return a.includes("chrome://") || a.includes("chrome-extension://") || a.includes("moz-extension://")
};

function dh() {
    if (!eh) {
        var a = eh = new fh;
        a.G.length = 0;
        a.D.length = 0;
        gh(a, ch)
    }
    return eh
}

function gh(a, b) {
    b.G && a.G.push.apply(a.G, b.G);
    b.D && a.D.push.apply(a.D, b.D)
}
var fh = class {
        constructor() {
            this.D = [];
            this.G = []
        }
    },
    eh;
const hh = new F;

function ih(a) {
    const b = a.length;
    let c = 0;
    const d = () => a.charCodeAt(c++);
    do {
        var e = jh(d);
        if (Infinity === e) break;
        const f = e >> 3;
        switch (e & 7) {
            case 0:
                e = jh(d);
                if (2 === f) return e;
                break;
            case 1:
                if (2 === f) return;
                c += 8;
                break;
            case 2:
                e = jh(d);
                if (2 === f) return a.substr(c, e);
                c += e;
                break;
            case 5:
                if (2 === f) return;
                c += 4;
                break;
            default:
                return
        }
    } while (c < b)
}

function jh(a) {
    let b = a(),
        c = b & 127;
    if (128 > b) return c;
    b = a();
    c |= (b & 127) << 7;
    if (128 > b) return c;
    b = a();
    c |= (b & 127) << 14;
    if (128 > b) return c;
    b = a();
    return 128 > b ? c | (b & 127) << 21 : Infinity
};

function kh(a, b, c, d) {
    if (a)
        if (Array.isArray(a)) {
            var e = d;
            for (d = 0; d < a.length && !(a[d] && (e += lh(d, a[d], b, c), 500 < e)); d++);
            d = e
        } else if ("object" === typeof a)
        for (e in a) {
            if (a[e]) {
                var f = e;
                var g = a[e],
                    h = b,
                    k = c;
                f = "string" !== typeof g || "clickTrackingParams" !== f && "trackingParams" !== f ? 0 : (g = ih(atob(g.replace(/-/g, "+").replace(/_/g, "/")))) ? lh(`${f}.ve`, g, h, k) : 0;
                d += f;
                d += lh(e, a[e], b, c);
                if (500 < d) break
            }
        } else c[b] = mh(a), d += c[b].length;
    else c[b] = mh(a), d += c[b].length;
    return d
}

function lh(a, b, c, d) {
    c += `.${a}`;
    a = mh(b);
    d[c] = a;
    return c.length + a.length
}

function mh(a) {
    try {
        return ("string" === typeof a ? a : String(JSON.stringify(a))).substr(0, 500)
    } catch (b) {
        return `unable to serialize ${typeof a} (${b.message})`
    }
};
var nh = new Set,
    oh = 0,
    ph = 0,
    qh = 0,
    rh = [];
const sh = ["PhantomJS", "Googlebot", "TO STOP THIS SECURITY SCAN go/scan"];

function th(a) {
    uh(a)
}

function vh(a) {
    uh(a, "WARNING")
}

function uh(a, b = "ERROR") {
    var c = {};
    c.name = K("INNERTUBE_CONTEXT_CLIENT_NAME", 1);
    c.version = K("INNERTUBE_CONTEXT_CLIENT_VERSION", void 0);
    wh(a, c || {}, b)
}

function wh(a, b, c = "ERROR") {
    if (a) {
        a.hasOwnProperty("level") && a.level && (c = a.level);
        if (L("console_log_js_exceptions")) {
            var d = [];
            d.push(`Name: ${a.name}`);
            d.push(`Message: ${a.message}`);
            a.hasOwnProperty("params") && d.push(`Error Params: ${JSON.stringify(a.params)}`);
            a.hasOwnProperty("args") && d.push(`Error args: ${JSON.stringify(a.args)}`);
            d.push(`File name: ${a.fileName}`);
            d.push(`Stacktrace: ${a.stack}`);
            window.console.log(d.join("\n"), a)
        }
        if (!(5 <= oh)) {
            d = rh;
            var e = nc(a);
            const G = e.message || "Unknown Error",
                H = e.name || "UnknownError";
            var f = e.stack || a.i || "Not available";
            if (f.startsWith(`${H}: ${G}`)) {
                var g = f.split("\n");
                g.shift();
                f = g.join("\n")
            }
            g = e.lineNumber || "Not available";
            e = e.fileName || "Not available";
            let P = 0;
            if (a.hasOwnProperty("args") && a.args && a.args.length)
                for (var h = 0; h < a.args.length && !(P = kh(a.args[h], `params.${h}`, b, P), 500 <= P); h++);
            else if (a.hasOwnProperty("params") && a.params) {
                const Q = a.params;
                if ("object" === typeof a.params)
                    for (h in Q) {
                        if (!Q[h]) continue;
                        const ka = `params.${h}`,
                            tf = mh(Q[h]);
                        b[ka] = tf;
                        P += ka.length + tf.length;
                        if (500 < P) break
                    } else b.params = mh(Q)
            }
            if (d.length)
                for (h = 0; h < d.length && !(P = kh(d[h], `params.context.${h}`, b, P), 500 <= P); h++);
            navigator.vendor && !b.hasOwnProperty("vendor") && (b["device.vendor"] = navigator.vendor);
            b = {
                message: G,
                name: H,
                lineNumber: g,
                fileName: e,
                stack: f,
                params: b,
                sampleWeight: 1
            };
            d = Number(a.columnNumber);
            isNaN(d) || (b.lineNumber = `${b.lineNumber}:${d}`);
            if ("IGNORED" === a.level) var k = 0;
            else a: {
                a = dh();d = b;
                for (k of a.G)
                    if (d.message && d.message.match(k.Ba)) {
                        k = k.weight;
                        break a
                    }
                for (var l of a.D)
                    if (l.pa(d)) {
                        k =
                            l.weight;
                        break a
                    }
                k = 1
            }
            b.sampleWeight = k;
            k = b;
            for (var m of ah)
                if (m.S[k.name]) {
                    l = m.S[k.name];
                    for (var p of l)
                        if (l = k.message.match(p.v)) {
                            k.params["params.error.original"] = l[0];
                            a = p.groups;
                            b = {};
                            for (d = 0; d < a.length; d++) b[a[d]] = l[d + 1], k.params[`params.error.${a[d]}`] = l[d + 1];
                            k.message = m.Y(b);
                            break
                        }
                }
            k.params || (k.params = {});
            m = dh();
            k.params["params.errorServiceSignature"] = `msg=${m.G.length}&cb=${m.D.length}`;
            k.params["params.serviceWorker"] = "true";
            t.document && t.document.querySelectorAll && (k.params["params.fscripts"] =
                String(document.querySelectorAll("script:not([nonce])").length));
            wa("sample").constructor !== va && (k.params["params.fconst"] = "true");
            window.yterr && "function" === typeof window.yterr && window.yterr(k);
            if (0 !== k.sampleWeight && !nh.has(k.message)) {
                "ERROR" === c ? (hh.Z("handleError", k), L("record_app_crashed_web") && 0 === qh && 1 === k.sampleWeight && (qh++, m = {
                    appCrashType: "APP_CRASH_TYPE_BREAKPAD"
                }, L("report_client_error_with_app_crash_ks") || (m.systemHealth = {
                    crashData: {
                        clientError: {
                            logMessage: {
                                message: k.message
                            }
                        }
                    }
                }), W("appCrashed",
                    m)), ph++) : "WARNING" === c && hh.Z("handleWarning", k);
                b: {
                    for (u of sh)
                        if ((m = za()) && 0 <= m.toLowerCase().indexOf(u.toLowerCase())) {
                            var u = !0;
                            break b
                        }
                    u = !1
                }
                if (u) var n = void 0;
                else {
                    m = {
                        stackTrace: k.stack
                    };
                    k.fileName && (m.filename = k.fileName);
                    u = k.lineNumber && k.lineNumber.split ? k.lineNumber.split(":") : [];
                    0 !== u.length && (1 !== u.length || isNaN(Number(u[0])) ? 2 !== u.length || isNaN(Number(u[0])) || isNaN(Number(u[1])) || (m.lineNumber = Number(u[0]), m.columnNumber = Number(u[1])) : m.lineNumber = Number(u[0]));
                    u = {
                        level: "ERROR_LEVEL_UNKNOWN",
                        message: k.message,
                        errorClassName: k.name,
                        sampleWeight: k.sampleWeight
                    };
                    "ERROR" === c ? u.level = "ERROR_LEVEL_ERROR" : "WARNING" === c && (u.level = "ERROR_LEVEL_WARNNING");
                    m = {
                        isObfuscated: !0,
                        browserStackInfo: m
                    };
                    p = {
                        pageUrl: window.location.href,
                        kvPairs: []
                    };
                    K("FEXP_EXPERIMENTS") && (p.experimentIds = K("FEXP_EXPERIMENTS"));
                    l = K("LATEST_ECATCHER_SERVICE_TRACKING_PARAMS", void 0);
                    a = I.EXPERIMENT_FLAGS;
                    if ((!a || !a.web_disable_gel_stp_ecatcher_killswitch) && l)
                        for (var x of Object.keys(l)) p.kvPairs.push({
                            key: x,
                            value: String(l[x])
                        });
                    if (x = k.params)
                        for (n of Object.keys(x)) p.kvPairs.push({
                            key: `client.${n}`,
                            value: String(x[n])
                        });
                    n = K("SERVER_NAME", void 0);
                    x = K("SERVER_VERSION", void 0);
                    n && x && (p.kvPairs.push({
                        key: "server.name",
                        value: n
                    }), p.kvPairs.push({
                        key: "server.version",
                        value: x
                    }));
                    n = {
                        errorMetadata: p,
                        stackTrace: m,
                        logMessage: u
                    }
                }
                n && (W("clientError", n), ("ERROR" === c || L("errors_flush_gel_always_killswitch")) && He());
                try {
                    nh.add(k.message)
                } catch (Q) {}
                oh++
            }
        }
    }
};
const xh = t.ytLoggingGelSequenceIdObj_ || {};

function yh(a, b, c = {}) {
    var d = Math.round(c.timestamp || M());
    B(a, 1, d < Number.MAX_SAFE_INTEGER ? d : 0);
    var e = fe();
    d = new ud;
    B(d, 1, c.timestamp || !isFinite(e) ? -1 : e);
    if (L("log_sequence_info_on_gel_web") && c.A) {
        e = c.A;
        const f = Ze(e),
            g = new td;
        B(g, 2, f);
        B(g, 1, e);
        C(d, 3, g);
        c.ha && delete xh[c.A]
    }
    C(a, 33, d);
    (c.Da ? Le : Ge)({
        endpoint: "log_event",
        payload: a,
        cttAuthInfo: c.cttAuthInfo,
        K: c.K
    }, b)
};

function zh(a, b = {}) {
    let c = !1;
    K("ytLoggingEventsDefaultDisabled", !1) && Jg === Ig && (c = !0);
    yh(a, c ? null : Jg, b)
};

function Ah(a, b, c) {
    const d = new vd;
    qb(d, 72, a);
    c ? yh(d, c, b) : zh(d, b)
}

function Bh(a, b, c) {
    const d = new vd;
    qb(d, 73, a);
    c ? yh(d, c, b) : zh(d, b)
}

function Ch(a, b, c) {
    const d = new vd;
    qb(d, 78, a);
    c ? yh(d, c, b) : zh(d, b)
}

function Dh(a, b, c) {
    const d = new vd;
    qb(d, 208, a);
    c ? yh(d, c, b) : zh(d, b)
}

function Eh(a, b, c) {
    const d = new vd;
    qb(d, 156, a);
    c ? yh(d, c, b) : zh(d, b)
}

function Fh(a, b, c) {
    const d = new vd;
    qb(d, 215, a);
    c ? yh(d, c, b) : zh(d, b)
};
class pg extends ng {
    constructor(a) {
        super(arguments);
        this.csn = a
    }
}
const vg = new og,
    Gh = [];
let Ih = Hh,
    Jh = 0;

function Kh(a, b, c, d, e, f, g) {
    const h = Ih();
    f = new Sg({
        veType: b,
        youtubeData: f,
        jspbYoutubeData: void 0
    });
    e = {
        cttAuthInfo: e,
        A: h
    };
    const k = () => {
        vh(new R("newScreen() parent element does not have a VE - rootVe", b))
    };
    if (L("il_via_jspb")) {
        const l = new kd;
        l.B(h);
        jd(l, f.getAsJspb());
        c && c.visualElement ? (f = new md, c.clientScreenNonce && B(f, 2, c.clientScreenNonce), ld(f, c.visualElement.getAsJspb()), g && B(f, 4, id[g]), C(l, 5, f)) : c && k();
        d && B(l, 3, d);
        Eh(l, e, a)
    } else f = {
        csn: h,
        pageVe: f.getAsJson()
    }, c && c.visualElement ? (f.implicitGesture = {
        parentCsn: c.clientScreenNonce,
        gesturedVe: c.visualElement.getAsJson()
    }, g && (f.implicitGesture.gestureType = g)) : c && k(), d && (f.cloneCsn = d), a ? O("screenCreated", f, a, e) : W("screenCreated", f, e);
    ug(new pg(h));
    return h
}

function Lh(a, b, c, d) {
    const e = d.filter(g => {
            g.csn !== b ? (g.csn = b, g = !0) : g = !1;
            return g
        }),
        f = {
            cttAuthInfo: Zg(b),
            A: b
        };
    for (const g of d) d = g.getAsJson(), (ra(d) || !d.trackingParams && !d.veType) && vh(Error("Child VE logged with no data"));
    if (L("il_via_jspb")) {
        const g = new pd;
        g.B(b);
        nd(g, c.getAsJspb());
        pa(e, h => {
            h = h.getAsJspb();
            sb(g, 3, hd, h, void 0)
        });
        "UNDEFINED_CSN" == b ? Y("visualElementAttached", g, f) : Fh(g, f, a)
    } else c = {
        csn: b,
        parentVe: c.getAsJson(),
        childVes: pa(e, g => g.getAsJson())
    }, "UNDEFINED_CSN" == b ? Y("visualElementAttached", c, f) : a ? O("visualElementAttached", c, a, f) : W("visualElementAttached", c, f)
}

function Mh(a, b, c, d, e) {
    const f = {
        cttAuthInfo: Zg(b),
        A: b
    };
    if (L("il_via_jspb")) {
        const g = new rd;
        g.B(b);
        c = c.getAsJspb();
        C(g, 2, c);
        B(g, 4, 1);
        d && C(g, 3, e);
        "UNDEFINED_CSN" == b ? Y("visualElementShown", g, f) : Ah(g, f, a)
    } else e = {
        csn: b,
        ve: c.getAsJson(),
        eventType: 1
    }, d && (e.clientData = d), "UNDEFINED_CSN" == b ? Y("visualElementShown", e, f) : a ? O("visualElementShown", e, a, f) : W("visualElementShown", e, f)
}

function Nh(a, b, c, d = !1) {
    var e = d ? 16 : 8;
    const f = {
        cttAuthInfo: Zg(b),
        A: b,
        ha: d
    };
    L("il_via_jspb") ? (e = new rd, e.B(b), c = c.getAsJspb(), C(e, 2, c), B(e, 4, d ? 16 : 8), "UNDEFINED_CSN" == b ? Y("visualElementHidden", e, f) : Bh(e, f, a)) : (d = {
        csn: b,
        ve: c.getAsJson(),
        eventType: e
    }, "UNDEFINED_CSN" == b ? Y("visualElementHidden", d, f) : a ? O("visualElementHidden", d, a, f) : W("visualElementHidden", d, f))
}

function Oh(a, b, c, d) {
    var e = "INTERACTION_LOGGING_GESTURE_TYPE_GENERIC_CLICK";
    const f = {
        cttAuthInfo: Zg(b),
        A: b
    };
    if (L("il_via_jspb")) {
        const g = new qd;
        g.B(b);
        c = c.getAsJspb();
        C(g, 2, c);
        B(g, 4, id[e]);
        d && C(g, 3, void 0);
        "UNDEFINED_CSN" == b ? Y("visualElementGestured", g, f) : Ch(g, f, a)
    } else e = {
        csn: b,
        ve: c.getAsJson(),
        gestureType: e
    }, d && (e.clientData = d), "UNDEFINED_CSN" == b ? Y("visualElementGestured", e, f) : a ? O("visualElementGestured", e, a, f) : W("visualElementGestured", e, f)
}

function Hh() {
    for (var a = Math.random() + "", b = [], c = 0, d = 0; d < a.length; d++) {
        var e = a.charCodeAt(d);
        255 < e && (b[c++] = e & 255, e >>= 8);
        b[c++] = e
    }
    return Ma(b, 3)
}

function Y(a, b, c) {
    Gh.push({
        payloadName: a,
        payload: b,
        options: c
    });
    Jh || (Jh = yg())
}

function zg(a) {
    if (Gh) {
        for (let b of Gh)
            if (b.payload)
                if (L("il_via_jspb")) switch (b.payload.B(a.csn), b.payloadName) {
                    case "screenCreated":
                        Eh(b.payload, b.options);
                        break;
                    case "visualElementAttached":
                        Fh(b.payload, b.options);
                        break;
                    case "visualElementShown":
                        Ah(b.payload, b.options);
                        break;
                    case "visualElementHidden":
                        Bh(b.payload, b.options);
                        break;
                    case "visualElementGestured":
                        Ch(b.payload, b.options);
                        break;
                    case "visualElementStateChanged":
                        Dh(b.payload, b.options);
                        break;
                    default:
                        vh(new R("flushQueue unable to map payloadName to JSPB setter"))
                } else b.payload.csn =
                    a.csn, O(b.payloadName, b.payload, null, b.options);
        Gh.length = 0
    }
    Jh = 0
};

function Ph(a, b) {
    return b.data && b.data.loggingDirectives ? b.data.loggingDirectives.trackingParams || "" : b.data && b.data.trackingParams || ""
}

function Qh(a, b) {
    const c = X(void 0);
    return null !== a.j && c != a.j ? (vh(new R("VisibilityLogger called before newScreen()", {
        caller: b.tagName,
        previous_csn: a.csn,
        current_csn: c
    })), null) : c
}

function Rh(a) {
    return parseInt(a.data && a.data.loggingDirectives && a.data.loggingDirectives.visibility && a.data.loggingDirectives.visibility.types || "", 10) || 1
}

function Sh(a, b) {
    var c = Ph(0, b),
        d = b.visualElement ? b.visualElement : c,
        e = a.m.has(d);
    const f = a.i.get(d);
    a.m.add(d);
    a.i.set(d, !0);
    b.h && !e && b.h();
    if (c || b.visualElement)
        if (d = Qh(a, b)) {
            var g = !(!b.data || !b.data.loggingDirectives);
            if (Rh(b) || g) {
                var h = b.visualElement ? b.visualElement : new Sg({
                    trackingParams: c
                });
                c = b.i;
                var k = b.j;
                g || e ? Rh(b) & 4 ? f || (a = a.h, b = {
                    cttAuthInfo: Zg(d),
                    A: d
                }, L("il_via_jspb") ? (e = new rd, e.B(d), h = h.getAsJspb(), C(e, 2, h), B(e, 4, 4), c && C(e, 3, k), "UNDEFINED_CSN" == d ? Y("visualElementShown", e, b) : Ah(e, b, a)) : (k = {
                    csn: d,
                    ve: h.getAsJson(),
                    eventType: 4
                }, c && (k.clientData = c), "UNDEFINED_CSN" == d ? Y("visualElementShown", k, b) : a ? O("visualElementShown", k, a, b) : W("visualElementShown", k, b))) : Rh(b) & 1 && !e && Mh(a.h, d, h, c, k) : Mh(a.h, d, h, c)
            }
        }
}
class Th {
    constructor() {
        this.m = new Set;
        this.l = new Set;
        this.i = new Map;
        this.j = null;
        this.h = Ig
    }
    clear() {
        this.m.clear();
        this.l.clear();
        this.i.clear();
        this.j = null
    }
}(function() {
    var a = Th;
    a.X = void 0;
    a.s = function() {
        return a.X ? a.X : a.X = new a
    }
})();
var Uh = a => self.btoa(String.fromCharCode.apply(null, Array.from(new Uint8Array(a)))).replace(/\+/g, "-").replace(/\//g, "_");
var Vh = ["notifications_register", "notifications_check_registration"];
let Wh = null;

function Z(a, b) {
    const c = {};
    c.key = a;
    c.value = b;
    return Xh().then(d => new Promise((e, f) => {
        try {
            const g = d.transaction("swpushnotificationsstore", "readwrite").objectStore("swpushnotificationsstore").put(c);
            g.onsuccess = () => {
                e()
            };
            g.onerror = () => {
                f()
            }
        } catch (g) {
            f(g)
        }
    }))
}

function Yh() {
    return Z("IndexedDBCheck", "testing IndexedDB").then(() => Zh("IndexedDBCheck")).then(a => "testing IndexedDB" === a ? Promise.resolve() : Promise.reject()).then(() => !0).catch(() => !1)
}

function Zh(a) {
    const b = new R("Error accessing DB");
    return Xh().then(c => new Promise((d, e) => {
        try {
            const f = c.transaction("swpushnotificationsstore").objectStore("swpushnotificationsstore").get(a);
            f.onsuccess = () => {
                const g = f.result;
                d(g ? g.value : null)
            };
            f.onerror = () => {
                b.params = {
                    key: a,
                    source: "onerror"
                };
                e(b)
            }
        } catch (f) {
            b.params = {
                key: a,
                thrownError: String(f)
            }, e(b)
        }
    }), () => null)
}

function Xh() {
    return Wh ? Promise.resolve(Wh) : new Promise((a, b) => {
        const c = self.indexedDB.open("swpushnotificationsdb");
        c.onerror = b;
        c.onsuccess = () => {
            const d = c.result;
            if (d.objectStoreNames.contains("swpushnotificationsstore")) Wh = d, a(Wh);
            else return self.indexedDB.deleteDatabase("swpushnotificationsdb"), Xh()
        };
        c.onupgradeneeded = $h
    })
}

function $h(a) {
    a = a.target.result;
    a.objectStoreNames.contains("swpushnotificationsstore") && a.deleteObjectStore("swpushnotificationsstore");
    a.createObjectStore("swpushnotificationsstore", {
        keyPath: "key"
    })
};
const ai = {
    WEB_UNPLUGGED: "^unplugged/",
    WEB_UNPLUGGED_ONBOARDING: "^unplugged/",
    WEB_UNPLUGGED_OPS: "^unplugged/",
    WEB_UNPLUGGED_PUBLIC: "^unplugged/",
    WEB_CREATOR: "^creator/",
    WEB_KIDS: "^kids/",
    WEB_EXPERIMENTS: "^experiments/",
    WEB_MUSIC: "^music/",
    WEB_REMIX: "^music/",
    WEB_MUSIC_EMBEDDED_PLAYER: "^music/",
    WEB_MUSIC_EMBEDDED_PLAYER: "^main_app/|^sfv/"
};

function bi(a) {
    if (1 === a.length) return a[0];
    var b = ai.UNKNOWN_INTERFACE;
    if (b) {
        b = new RegExp(b);
        for (var c of a)
            if (b.exec(c)) return c
    }
    const d = [];
    Object.entries(ai).forEach(([e, f]) => {
        "UNKNOWN_INTERFACE" !== e && d.push(f)
    });
    c = new RegExp(d.join("|"));
    a.sort((e, f) => e.length - f.length);
    for (const e of a)
        if (!c.exec(e)) return e;
    return a[0]
}

function ci(a) {
    return `/youtubei/v1/${bi(a)}`
};
const di = window;
class ei {
    constructor() {
        this.timing = {};
        this.clearResourceTimings = () => {};
        this.webkitClearResourceTimings = () => {};
        this.mozClearResourceTimings = () => {};
        this.msClearResourceTimings = () => {};
        this.oClearResourceTimings = () => {}
    }
}
var fi = di.performance || di.mozPerformance || di.msPerformance || di.webkitPerformance || new ei;
la(fi.clearResourceTimings || fi.webkitClearResourceTimings || fi.mozClearResourceTimings || fi.msClearResourceTimings || fi.oClearResourceTimings || ha, fi);
w("ytLoggingLatencyUsageStats_", t.ytLoggingLatencyUsageStats_ || {});

function gi() {
    hi.h || (hi.h = new hi);
    return hi.h
}

function ii(a, b, c = {}) {
    a.i.add(c.layer || 0);
    a.j = () => {
        ji(a, b, c);
        var d = Wg(c.layer);
        if (d) {
            for (var e of a.m) ki(a, e[0], e[1] || d, c.layer);
            for (const k of a.C) {
                e = X(0);
                var f = k[0] || Wg(0);
                if (e && f) {
                    d = a.client;
                    var g = f,
                        h = k[1];
                    f = {
                        cttAuthInfo: Zg(e),
                        A: e
                    };
                    L("il_via_jspb") ? (h = new sd, h.B(e), g = g.getAsJspb(), C(h, 2, g), "UNDEFINED_CSN" == e ? Y("visualElementStateChanged", h, f) : Dh(h, f, d)) : (g = {
                        csn: e,
                        ve: g.getAsJson(),
                        clientData: h
                    }, "UNDEFINED_CSN" == e ? Y("visualElementStateChanged", g, f) : d ? O("visualElementStateChanged", g, d, f) : W("visualElementStateChanged",
                        g, f))
                }
            }
        }
    };
    X(c.layer) || a.j();
    if (c.fa)
        for (const d of c.fa) li(a, d, c.layer);
    else uh(Error("Delayed screen needs a data promise."))
}

function ji(a, b, c = {}) {
    c.layer || (c.layer = 0);
    var d = void 0 !== c.Ca ? c.Ca : c.layer;
    var e = X(d);
    d = Wg(d);
    let f;
    d && (void 0 !== c.parentCsn ? f = {
        clientScreenNonce: c.parentCsn,
        visualElement: d
    } : e && "UNDEFINED_CSN" !== e && (f = {
        clientScreenNonce: e,
        visualElement: d
    }));
    let g;
    const h = K("EVENT_ID");
    "UNDEFINED_CSN" === e && h && (g = {
        servletData: {
            serializedServletEventId: h
        }
    });
    let k;
    try {
        k = Kh(a.client, b, f, c.ea, c.cttAuthInfo, g, c.sb)
    } catch (m) {
        a = m;
        c = [{
            Db: b,
            rootVe: d,
            parentVisualElement: void 0,
            qb: e,
            yb: f,
            ea: c.ea
        }];
        a.args || (a.args = []);
        a.args.push(...c);
        uh(m);
        return
    }
    $g(k, b, c.layer, c.cttAuthInfo);
    if ((b = e && "UNDEFINED_CSN" !== e && d) && !(b = L("screen_manager_skip_hide_killswitch"))) {
        a: {
            for (l of Object.values(Pg))
                if (X(l) == e) {
                    var l = !0;
                    break a
                }
            l = !1
        }
        b = !l
    }
    b && Nh(a.client, e, d, !0);
    a.h[a.h.length - 1] && !a.h[a.h.length - 1].csn && (a.h[a.h.length - 1].csn = k || "");
    d = Th.s();
    d.clear();
    d.j = X();
    d = Wg(c.layer);
    e && "UNDEFINED_CSN" !== e && d && (L("web_mark_root_visible") || L("music_web_mark_root_visible")) && Mh(void 0, k, d, void 0);
    a.i.delete(c.layer || 0);
    a.j = void 0;
    for (const [m, p] of a.M) e =
        m, p.has(c.layer) && d && ki(a, e, d, c.layer);
    for (c = 0; c < a.l.length; c++) {
        e = a.l[c];
        try {
            e()
        } catch (m) {
            uh(m)
        }
    }
    a.l.length = 0;
    for (c = 0; c < a.o.length; c++) {
        e = a.o[c];
        try {
            e()
        } catch (m) {
            uh(m)
        }
    }
}

function mi(a) {
    var b = 28631,
        c = {
            layer: 8
        };
    [28631].includes(b) || (vh(new R("createClientScreen() called with a non-page VE", b)), b = 83769);
    c.isHistoryNavigation || a.h.push({
        rootVe: b,
        key: c.key || ""
    });
    a.m = [];
    a.C = [];
    c.fa ? ii(a, b, c) : ji(a, b, c)
}

function li(a, b, c = 0) {
    b.then(d => {
        a.i.has(c) && a.j && a.j();
        const e = X(c),
            f = Wg(c);
        if (e && f) {
            var g;
            (null == d ? 0 : null == (g = d.response) ? 0 : g.trackingParams) && Lh(a.client, e, f, [new Sg({
                trackingParams: d.response.trackingParams
            })]);
            var h;
            (null == d ? 0 : null == (h = d.playerResponse) ? 0 : h.trackingParams) && Lh(a.client, e, f, [new Sg({
                trackingParams: d.playerResponse.trackingParams
            })])
        }
    })
}

function ki(a, b, c, d = 0) {
    if (a.i.has(d)) a.m.push([b, c]);
    else {
        var e = X(d);
        c = c || Wg(d);
        e && c && Lh(a.client, e, c, [b])
    }
}

function ni(a, b) {
    b = new Sg({
        trackingParams: b
    });
    ki(a, b, void 0, 8);
    return b
}

function oi(a, b, c = 0) {
    (c = X(c)) && Oh(a.client, c, b, void 0)
}

function pi(a, b, c, d = 0) {
    if (!b) return !1;
    d = X(d);
    if (!d) return !1;
    Oh(a.client, d, new Sg({
        trackingParams: b
    }), c);
    return !0
}

function qi(a, b) {
    const c = b.va && b.va();
    b.visualElement ? oi(a, b.visualElement, c) : (b = Ph(Th.s(), b), pi(a, b, void 0, c))
}
var hi = class {
    constructor() {
        this.m = [];
        this.C = [];
        this.h = [];
        this.l = [];
        this.o = [];
        this.i = new Set;
        this.M = new Map
    }
    clickCommand(a, b, c = 0) {
        return pi(this, a.clickTrackingParams, b, c)
    }
};
var ri = class extends D {
    constructor(a) {
        super(a)
    }
};
var si = class extends D {
    constructor(a) {
        super(a)
    }
};
si.ma = "yt.sw.adr";

function ti(a) {
    return r(function*() {
        var b = yield t.fetch(a.i);
        if (200 !== b.status) return Promise.reject("Server error when retrieving AmbientData");
        b = yield b.text();
        if (!b.startsWith(")]}'\n")) return Promise.reject("Incorrect JSPB formatting");
        a: {
            b = JSON.parse(b.substring(5));
            for (let c = 0; c < b.length; c++)
                if (b[c][0] === (new si).constructor.ma) {
                    b = new si(b[c]);
                    break a
                }
            b = null
        }
        return b ? b : Promise.reject("AmbientData missing from response")
    })
}

function ui(a = !1) {
    const b = vi.h;
    return r(function*() {
        if (a || !b.h) b.h = ti(b).then(b.j).catch(c => {
            delete b.h;
            uh(c)
        });
        return b.h
    })
}
var vi = class {
    constructor() {
        this.i = `${self.location.origin}/sw.js_data`
    }
    j(a) {
        const b = ob(a, ri, 2);
        if (b) {
            const c = A(b, 5);
            c && (t.__SAPISID = c);
            L("enable_web_eom_visitor_data") && null != A(b, 10) ? J("EOM_VISITOR_DATA", A(b, 10)) : null != A(b, 7) && J("VISITOR_DATA", A(b, 7));
            null != A(b, 4) && J("SESSION_INDEX", String(A(b, 4)));
            null != A(b, 8) && J("DELEGATED_SESSION_ID", A(b, 8))
        }
        return a
    }
};

function wi(a) {
    const b = {};
    var c = lc();
    c && (b.Authorization = c, c = a = null == a ? void 0 : a.sessionIndex, void 0 === c && (c = Number(K("SESSION_INDEX", 0)), c = isNaN(c) ? 0 : c), b["X-Goog-AuthUser"] = c, "INNERTUBE_HOST_OVERRIDE" in I || (b["X-Origin"] = window.location.origin), void 0 === a && "DELEGATED_SESSION_ID" in I && (b["X-Goog-PageId"] = K("DELEGATED_SESSION_ID")));
    return b
}
var xi = class {
    constructor() {
        this.Fa = !0
    }
};
var yi = {
    identityType: "UNAUTHENTICATED_IDENTITY_TYPE_UNKNOWN"
};

function zi(a, b) {
    b.encryptedTokenJarContents && (a.h[b.encryptedTokenJarContents] = b, "string" === typeof b.expirationSeconds && setTimeout(() => {
        delete a.h[b.encryptedTokenJarContents]
    }, 1E3 * Number(b.expirationSeconds)))
}
var Ai = class {
    constructor() {
        this.h = {}
    }
    handleResponse(a, b) {
        let c, d;
        b = (null == (c = b.I.context) ? void 0 : null == (d = c.request) ? void 0 : d.consistencyTokenJars) || [];
        let e;
        if (a = null == (e = a.responseContext) ? void 0 : e.consistencyTokenJar) {
            for (const f of b) delete this.h[f.encryptedTokenJarContents];
            zi(this, a)
        }
    }
};

function Bi() {
    var a = K("INNERTUBE_CONTEXT");
    if (!a) return uh(Error("Error: No InnerTubeContext shell provided in ytconfig.")), {};
    a = sa(a);
    L("web_no_tracking_params_in_shell_killswitch") || delete a.clickTracking;
    a.client || (a.client = {});
    var b = a.client;
    b.utcOffsetMinutes = -Math.floor((new Date).getTimezoneOffset());
    var c = Sd();
    c ? b.experimentsToken = c : delete b.experimentsToken;
    Ai.h || (Ai.h = new Ai);
    b = Ai.h.h;
    c = [];
    let d = 0;
    for (const e in b) c[d++] = b[e];
    a.request = Object.assign({}, a.request, {
        consistencyTokenJars: c
    });
    a.user = Object.assign({}, a.user);
    return a
};

function Ci(a) {
    var b = a;
    if (a = K("INNERTUBE_HOST_OVERRIDE")) {
        a = String(a);
        var c = String,
            d = b.match(z);
        b = d[5];
        var e = d[6];
        d = d[7];
        var f = "";
        b && (f += b);
        e && (f += "?" + e);
        d && (f += "#" + d);
        b = a + c(f)
    }
    return b
};
var Di = class {};
const Ei = {
    GET_DATASYNC_IDS: function(a) {
        return () => new a
    }(class extends Di {})
};

function Fi(a) {
    var b = {
        pb: {}
    };
    xi.h || (xi.h = new xi);
    var c = xi.h;
    if (void 0 !== Gi.h) {
        const d = Gi.h;
        a = [b !== d.m, a !== d.l, c !== d.j, !1, !1, void 0 !== d.i];
        if (a.some(e => e)) throw new R("InnerTubeTransportService is already initialized", a);
    } else Gi.h = new Gi(b, a, c)
}

function Hi(a, b, c) {
    return r(function*() {
        var d;
        if (a.j.Fa) {
            const e = null == b ? void 0 : null == (d = b.da) ? void 0 : d.sessionIndex;
            d = wi({
                sessionIndex: e
            });
            d = Object.assign({}, Ii(c), d)
        } else d = Ji(b, c);
        return d
    })
}

function Ki(a, b, c) {
    return r(function*() {
        var d;
        const e = null == (d = b.config) ? void 0 : d.Cb;
        if (e && a.h.has(e) && L("web_memoize_inflight_requests")) return a.h.get(e);
        var f;
        if (null == b ? 0 : null == (f = b.I) ? 0 : f.context)
            for (const k of []) k.zb(b.I.context);
        let g;
        if (null == (g = a.i) ? 0 : g.l(b.input, b.I)) return a.i.j(b.input, b.I);
        d = JSON.stringify(b.I);
        b.U = Object.assign({}, b.U, {
            headers: c
        });
        f = Object.assign({}, b.U);
        "POST" === b.U.method && (f = Object.assign({}, f, {
            body: d
        }));
        d = a.l.fetch(b.input, f, b.config);
        e && a.h.set(e, d);
        d = yield d;
        e &&
            a.h.has(e) && a.h.delete(e);
        let h;
        !d && (null == (h = a.i) ? 0 : h.h(b.input, b.I)) && (d = yield a.i.i(b.input, b.I));
        return d
    })
}

function Li(a, b, c) {
    var d = {
        da: {
            identity: yi
        }
    };
    b.context || (b.context = Bi());
    return new E(e => r(function*() {
        var f = Ci(c);
        f = ne(f) ? "same-origin" : "cors";
        f = yield Hi(a, d, f);
        var g = Ci(c);
        var h = {};
        K("INNERTUBE_OMIT_API_KEY_WHEN_AUTH_HEADER_IS_PRESENT") && (null == f ? 0 : f.Authorization) || (h.key = K("INNERTUBE_API_KEY"));
        L("json_condensed_response") && (h.prettyPrint = "false");
        g = me(g, h || {}, !1);
        h = {
            method: "POST",
            mode: ne(g) ? "same-origin" : "cors",
            credentials: ne(g) ? "same-origin" : "include"
        };
        e(Ki(a, {
            input: g,
            U: h,
            I: b,
            config: d
        }, f))
    }))
}

function Ji(a, b) {
    return r(function*() {
        var c, d = {
            sessionIndex: null == a ? void 0 : null == (c = a.da) ? void 0 : c.sessionIndex
        };
        c = yield Ic(wi(d));
        return Promise.resolve(Object.assign({}, Ii(b), c))
    })
}

function Ii(a) {
    const b = {
        "Content-Type": "application/json"
    };
    L("enable_web_eom_visitor_data") && K("EOM_VISITOR_DATA") ? b["X-Goog-EOM-Visitor-Id"] = K("EOM_VISITOR_DATA") : K("VISITOR_DATA") && (b["X-Goog-Visitor-Id"] = K("VISITOR_DATA"));
    "cors" !== a && ((a = K("INNERTUBE_CONTEXT_CLIENT_NAME")) && (b["X-Youtube-Client-Name"] = a), (a = K("INNERTUBE_CONTEXT_CLIENT_VERSION")) && (b["X-Youtube-Client-Version"] = a), (a = K("CHROME_CONNECTED_HEADER")) && (b["X-Youtube-Chrome-Connected"] = a), L("forward_domain_admin_state_on_embeds") && (a =
        K("DOMAIN_ADMIN_STATE")) && (b["X-Youtube-Domain-Admin-State"] = a));
    return b
}
var Gi = class {
    constructor(a, b, c) {
        this.m = a;
        this.l = b;
        this.j = c;
        this.i = void 0;
        this.h = new Map;
        a.ba || (a.ba = {});
        a.ba = Object.assign({}, Ei, a.ba)
    }
};
let Mi;

function Ni() {
    Mi || (Fi({
        fetch: (a, b) => Ic(fetch(new Request(a, b)))
    }), Mi = Gi.h);
    return Mi
};

function Oi(a) {
    return r(function*() {
        yield Pi();
        vh(a)
    })
}

function Qi(a) {
    r(function*() {
        var b = yield gg();
        b ? yield Gg(a, b): (yield ui(), b = {
            timestamp: a.timestamp
        }, b = a.appShellAssetLoadReport ? {
            payloadName: "appShellAssetLoadReport",
            payload: a.appShellAssetLoadReport,
            options: b
        } : a.clientError ? {
            payloadName: "clientError",
            payload: a.clientError,
            options: b
        } : void 0, b && W(b.payloadName, b.payload))
    })
}

function Pi() {
    return r(function*() {
        try {
            yield ui()
        } catch (a) {}
    })
};
const Ri = {
    granted: "GRANTED",
    denied: "DENIED",
    unknown: "UNKNOWN"
};

function Si(a) {
    var b = a.data;
    a = b.type;
    b = b.data;
    "notifications_register" === a ? (Z("IDToken", b), Ti()) : "notifications_check_registration" === a && Ui(b)
}

function Vi() {
    return self.clients.matchAll({
        type: "window",
        includeUncontrolled: !0
    }).then(a => {
        if (a)
            for (const b of a) b.postMessage({
                type: "update_unseen_notifications_count_signal"
            })
    })
}

function Wi(a) {
    const b = [];
    a.forEach(c => {
        b.push({
            key: c.key,
            value: c.value
        })
    });
    return b
}

function Xi(a) {
    return r(function*() {
        const b = Wi(a.payload.chrome.extraUrlParams),
            c = {
                recipientId: a.recipientId,
                endpoint: a.payload.chrome.endpoint,
                extraUrlParams: b
            },
            d = ci(Bd);
        return Yi().then(e => Li(e, c, d).then(f => {
            f.json().then(g => {
                if (!g || !g.endpointUrl) return Promise.resolve();
                a.payload.chrome.postedEndpoint && Zi(a.payload.chrome.postedEndpoint);
                return $i(a, g.endpointUrl)
            })
        }))
    })
}

function aj(a, b) {
    var c = X(8);
    return null != c && b ? `${a}&parentCsn=${c}&parentTrackingParams=${b}` : a
}

function $i(a, b) {
    a.deviceId && Z("DeviceId", a.deviceId);
    a.timestampSec && Z("TimestampLowerBound", a.timestampSec);
    const c = a.payload.chrome,
        d = gi();
    mi(d);
    let e;
    const f = null == (e = c.postedEndpoint) ? void 0 : e.clickTrackingParams;
    if (f) {
        var g = ni(d, f);
        var h = Rg(82046);
        var k = Rg(74726);
        ki(d, h, g, 8);
        ki(d, k, g, 8);
        g = {
            na: 8,
            visualElement: g
        };
        k = {
            na: 8,
            visualElement: h
        };
        h = {
            na: 8,
            visualElement: h
        }
    }
    const l = {
        body: c.body,
        icon: c.iconUrl,
        data: {
            nav: aj(b, f),
            id: c.notificationId,
            attributionTag: c.attributionTag,
            clickEndpoint: c.clickEndpoint,
            parentElement: g,
            cancelElement: k,
            dismissalElement: h,
            isDismissed: !0
        },
        tag: c.notificationTag || c.title + c.body + c.iconUrl,
        requireInteraction: !0
    };
    return self.registration.showNotification(c.title, l).then(() => {
        let m;
        (null == (m = l.data) ? 0 : m.parentElement) && Sh(Th.s(), l.data.parentElement);
        let p;
        (null == (p = l.data) ? 0 : p.cancelElement) && Sh(Th.s(), l.data.cancelElement);
        let u;
        (null == (u = l.data) ? 0 : u.dismissalElement) && Sh(Th.s(), l.data.dismissalElement);
        bj(a.displayCap)
    }).catch(() => {})
}

function Zi(a) {
    if (!a.recordNotificationInteractionsEndpoint) return Promise.reject();
    const b = {
            serializedRecordNotificationInteractionsRequest: a.recordNotificationInteractionsEndpoint.serializedInteractionsRequest
        },
        c = ci(Cd);
    return Yi().then(d => Li(d, b, c))
}

function bj(a) {
    -1 !== a && self.registration.getNotifications().then(b => {
        for (let c = 0; c < b.length - a; c++) {
            b[c].data.isDismissed = !1;
            b[c].close();
            let d;
            (null == (d = b[c].data) ? 0 : d.cancelElement) && qi(gi(), b[c].data.cancelElement)
        }
    })
}

function Ui(a) {
    const b = [cj(a), Zh("RegistrationTimestamp").then(dj), ej(), fj(), gj()];
    Promise.all(b).catch(() => {
        Z("IDToken", a);
        Ti();
        return Promise.resolve()
    })
}

function dj(a) {
    a = a || 0;
    return 9E7 >= Date.now() - a ? Promise.resolve() : Promise.reject()
}

function cj(a) {
    return Zh("IDToken").then(b => a === b ? Promise.resolve() : Promise.reject())
}

function ej() {
    return Zh("Permission").then(a => Notification.permission === a ? Promise.resolve() : Promise.reject())
}

function fj() {
    return Zh("Endpoint").then(a => hj().then(b => a === b ? Promise.resolve() : Promise.reject()))
}

function gj() {
    return Zh("application_server_key").then(a => ij().then(b => a === b ? Promise.resolve() : Promise.reject()))
}

function jj() {
    var a = Notification.permission;
    if (Ri[a]) return Ri[a]
}

function Ti() {
    Z("RegistrationTimestamp", 0);
    Promise.all([hj(), kj(), lj(), ij()]).then(([a, b, c, d]) => {
        b = b ? Uh(b) : null;
        c = c ? Uh(c) : null;
        d = d ? Ma(new Uint8Array(d), 4) : null;
        mj(a, b, c, d)
    }).catch(() => {
        mj()
    })
}

function mj(a = null, b = null, c = null, d = null) {
    Yh().then(e => {
        e && (Z("Endpoint", a), Z("P256dhKey", b), Z("AuthKey", c), Z("application_server_key", d), Z("Permission", Notification.permission), Promise.all([Zh("DeviceId"), Zh("NotificationsDisabled")]).then(([f, g]) => {
            if (null != f) var h = f;
            else {
                f = [];
                var k;
                h = h || Vc.length;
                for (k = 0; 256 > k; k++) f[k] = Vc[0 | Math.random() * h];
                h = f.join("")
            }
            nj(h, null != a ? a : void 0, null != b ? b : void 0, null != c ? c : void 0, null != d ? d : void 0, null != g ? g : void 0)
        }))
    })
}

function nj(a, b, c, d, e, f) {
    r(function*() {
        const g = {
                notificationRegistration: {
                    chromeRegistration: {
                        deviceId: a,
                        pushParams: {
                            applicationServerKey: e,
                            authKey: d,
                            p256dhKey: c,
                            browserEndpoint: b
                        },
                        notificationsDisabledInApp: f,
                        permission: jj()
                    }
                }
            },
            h = ci(Dd);
        return Yi().then(k => Li(k, g, h).then(() => {
            Z("DeviceId", a);
            Z("RegistrationTimestamp", Date.now());
            Z("TimestampLowerBound", Date.now())
        }, l => {
            Oi(l)
        }))
    })
}

function hj() {
    return self.registration.pushManager.getSubscription().then(a => a ? Promise.resolve(a.endpoint) : Promise.resolve(null))
}

function kj() {
    return self.registration.pushManager.getSubscription().then(a => a && a.getKey ? Promise.resolve(a.getKey("p256dh")) : Promise.resolve(null))
}

function lj() {
    return self.registration.pushManager.getSubscription().then(a => a && a.getKey ? Promise.resolve(a.getKey("auth")) : Promise.resolve(null))
}

function ij() {
    return self.registration.pushManager.getSubscription().then(a => a ? Promise.resolve(a.options.applicationServerKey) : Promise.resolve(null))
}

function Yi() {
    return r(function*() {
        try {
            return yield ui(!0), Ni()
        } catch (a) {
            return yield Oi(a), Promise.reject(a)
        }
    })
};
let oj = void 0;

function pj(a) {
    return r(function*() {
        oj || (oj = yield a.open("yt-appshell-assets"));
        return oj
    })
}

function qj(a, b) {
    return r(function*() {
        const c = yield pj(a), d = b.map(e => rj(c, e));
        return Promise.all(d)
    })
}

function sj(a, b) {
    return r(function*() {
        let c;
        try {
            c = yield a.match(b, {
                cacheName: "yt-appshell-assets"
            })
        } catch (d) {}
        return c
    })
}

function tj(a, b) {
    return r(function*() {
        const c = yield pj(a), d = (yield c.keys()).filter(e => !b.includes(e.url)).map(e => c.delete(e));
        return Promise.all(d)
    })
}

function uj(a, b, c) {
    return r(function*() {
        yield(yield pj(a)).put(b, c)
    })
}

function vj(a, b) {
    r(function*() {
        yield(yield pj(a)).delete(b)
    })
}

function rj(a, b) {
    return r(function*() {
        return (yield a.match(b)) ? Promise.resolve() : a.add(b)
    })
};
var wj;
wj = Bg("yt-serviceworker-metadata", {
    L: {
        auth: {
            N: 1
        },
        ["resource-manifest-assets"]: {
            N: 2
        }
    },
    aa: !0,
    upgrade(a, b) {
        b(1) && Hf(a, "resource-manifest-assets");
        b(2) && Hf(a, "auth")
    },
    version: 2
});
let xj = null;

function yj(a) {
    return Yf(wj(), a)
}

function zj() {
    const a = Date.now();
    return IDBKeyRange.bound(0, a)
}

function Aj(a, b) {
    return r(function*() {
        yield V(yield yj(a.token), ["resource-manifest-assets"], "readwrite", c => {
            const d = c.objectStore("resource-manifest-assets"),
                e = Date.now();
            return U(d.h.put(b, e)).then(() => {
                xj = e;
                let f = !0;
                return Mf(d, {
                    query: zj(),
                    direction: "prev"
                }, g => f ? (f = !1, g.advance(5)) : d.delete(g.getKey()).then(() => g.continue()))
            })
        })
    })
}

function Bj(a, b) {
    return r(function*() {
        let c = !1,
            d = 0;
        yield V(yield yj(a.token), ["resource-manifest-assets"], "readonly", e => Mf(e.objectStore("resource-manifest-assets"), {
            query: zj(),
            direction: "prev"
        }, f => {
            if (f.ia().includes(b)) c = !0;
            else return d += 1, f.continue()
        }));
        return c ? d : -1
    })
}

function Cj(a) {
    return r(function*() {
        xj || (yield V(yield yj(a.token), ["resource-manifest-assets"], "readonly", b => Mf(b.objectStore("resource-manifest-assets"), {
            query: zj(),
            direction: "prev"
        }, c => {
            xj = c.getKey()
        })));
        return xj
    })
}
var Dj = class {
    constructor(a) {
        this.token = a
    }
    static s() {
        return r(function*() {
            const a = yield gg();
            if (a) return Dj.h || (Dj.h = new Dj(a)), Dj.h
        })
    }
};

function Ej(a, b) {
    return r(function*() {
        yield Jf(yield yj(a.token), "auth", b, "shell_identifier_key")
    })
}

function Fj(a) {
    return r(function*() {
        return (yield(yield yj(a.token)).get("auth", "shell_identifier_key")) || ""
    })
}

function Gj(a) {
    return r(function*() {
        yield(yield yj(a.token)).clear("auth")
    })
}
var Hj = class {
    constructor(a) {
        this.token = a
    }
    static s() {
        return r(function*() {
            const a = yield gg();
            if (a) return Hj.h || (Hj.h = new Hj(a)), Hj.h
        })
    }
};

function Ij() {
    r(function*() {
        const a = yield Hj.s();
        a && (yield Gj(a))
    })
};

function Jj() {
    return [1, Zb]
}
var Kj = class extends D {
    constructor(a) {
        super(a)
    }
};

function Wb() {
    return [1, $b, Kj, Jj]
}
var Vb = class extends D {
        constructor(a) {
            super(a, -1, Lj)
        }
    },
    Lj = [1];

function Mj(a) {
    return r(function*() {
        const b = a.headers.get("X-Resource-Manifest");
        return b ? Promise.resolve(Nj(b)) : Promise.reject(Error("No resource manifest header"))
    })
}

function Nj(a) {
    return pb(Xb(decodeURIComponent(a)), Kj, 1).reduce((b, c) => {
        (c = A(c, 1)) && b.push(c);
        return b
    }, [])
};

function Oj(a) {
    return r(function*() {
        const b = yield ui();
        if (b && null != A(b, 3)) {
            var c = yield Hj.s();
            c && (c = yield Fj(c), A(b, 3) !== c && (vj(a.h, a.i), Ij()))
        }
    })
}

function Pj(a) {
    return r(function*() {
        let b, c;
        try {
            c = yield Qj(a.j), b = yield Mj(c), yield qj(a.h, b)
        } catch (d) {
            return Promise.reject(d)
        }
        try {
            yield Rj(), yield uj(a.h, a.i, c)
        } catch (d) {
            return Promise.reject(d)
        }
        if (b) try {
            yield Sj(a, b, a.i)
        } catch (d) {}
        return Promise.resolve()
    })
}

function Tj(a) {
    return r(function*() {
        yield Oj(a);
        return Pj(a)
    })
}

function Qj(a) {
    return r(function*() {
        try {
            return yield t.fetch(new Request(a))
        } catch (b) {
            return Promise.reject(b)
        }
    })
}

function Rj() {
    return r(function*() {
        var a = yield ui();
        let b;
        a && null != A(a, 3) && (b = A(a, 3));
        return b ? (a = yield Hj.s()) ? Promise.resolve(Ej(a, b)) : Promise.reject(Error("Could not get AuthMonitor instance")) : Promise.reject(Error("Could not get datasync ID"))
    })
}

function Sj(a, b, c) {
    return r(function*() {
        const d = yield Dj.s();
        if (d) try {
            yield Aj(d, b)
        } catch (e) {
            yield Oi(e)
        }
        b.push(c);
        try {
            yield tj(a.h, b)
        } catch (e) {
            yield Oi(e)
        }
        return Promise.resolve()
    })
}

function Uj(a, b) {
    return r(function*() {
        return sj(a.h, b)
    })
}

function Vj(a) {
    return r(function*() {
        return sj(a.h, a.i)
    })
}
var Wj = class {
    constructor() {
        var a = self.location.origin + "/app_shell",
            b = self.location.origin + "/app_shell_home";
        this.h = self.caches;
        this.j = a;
        this.i = b
    }
};

function Xj(a, b) {
    return r(function*() {
        const c = b.request,
            d = yield Uj(a.h, c.url);
        if (d) return Qi({
            appShellAssetLoadReport: {
                assetPath: c.url,
                cacheHit: !0
            },
            timestamp: M()
        }), d;
        Yj(c);
        return Zj(b)
    })
}

function ak(a, b) {
    return r(function*() {
        const c = yield bk(b);
        if (c.response && (c.response.ok || "opaqueredirect" === c.response.type || 429 === c.response.status || 303 === c.response.status || 300 <= c.response.status && 400 > c.response.status)) return c.response;
        const d = yield Vj(a.h);
        if (d) return ck(a), d;
        dk(a);
        return c.response ? c.response : Promise.reject(c.error)
    })
}

function ek(a, b) {
    b = new URL(b);
    if (!a.i.includes(b.pathname)) return !1;
    if (!b.search) return !0;
    for (const c of a.l)
        if (a = b.searchParams.get(c.key), void 0 === c.value || a === c.value)
            if (b.searchParams.delete(c.key), !b.search) return !0;
    return !1
}

function fk(a, b) {
    return r(function*() {
        const c = yield Vj(a.h);
        if (!c) return dk(a), Zj(b);
        ck(a);
        var d;
        a: {
            if (c.headers && (d = c.headers.get("date")) && (d = Date.parse(d), !isNaN(d))) {
                d = Math.round(M() - d);
                break a
            }
            d = -1
        }
        if (!(-1 < d && 7 <= d / 864E5)) return c;
        d = yield bk(b);
        return d.response && d.response.ok ? d.response : c
    })
}

function Zj(a) {
    return Promise.resolve(a.preloadResponse).then(b => b || t.fetch(a.request))
}

function Yj(a) {
    const b = {
        assetPath: a.url,
        cacheHit: !1
    };
    Dj.s().then(c => {
        if (c) {
            var d = Cj(c).then(e => {
                e && (b.currentAppBundleTimestampSec = String(Math.floor(e / 1E3)))
            });
            c = Bj(c, a.url).then(e => {
                b.appBundleVersionDiffCount = e
            });
            Promise.all([d, c]).catch(e => {
                Oi(e)
            }).finally(() => {
                Qi({
                    appShellAssetLoadReport: b,
                    timestamp: M()
                })
            })
        } else Qi({
            appShellAssetLoadReport: b,
            timestamp: M()
        })
    })
}

function ck(a) {
    Qi({
        appShellAssetLoadReport: {
            assetPath: a.h.i,
            cacheHit: !0
        },
        timestamp: M()
    })
}

function dk(a) {
    Qi({
        appShellAssetLoadReport: {
            assetPath: a.h.i,
            cacheHit: !1
        },
        timestamp: M()
    })
}

function bk(a) {
    return r(function*() {
        try {
            return {
                response: yield Zj(a)
            }
        } catch (b) {
            return {
                error: b
            }
        }
    })
}
var lk = class {
    constructor() {
        var a = gk,
            b = hk,
            c = ik,
            d = jk;
        const e = [];
        e.push({
            key: "feature",
            value: "ytca"
        });
        for (var f of cc) e.push({
            key: f
        });
        f = kk();
        this.h = a;
        this.m = b;
        this.o = c;
        this.i = d;
        this.l = e;
        this.j = f
    }
};
var jk = ["/", "/feed/downloads"];
const mk = [/^\/$/, /^\/feed\/downloads$/],
    nk = [/^\/$/, /^\/feed\/\w*/, /^\/results$/, /^\/playlist$/, /^\/watch$/, /^\/channel\/\w*/];

function kk() {
    return new RegExp((L("kevlar_sw_app_wide_fallback") ? nk : mk).map(a => a.source).join("|"))
}
var hk = /^https:\/\/[\w-]*\.?youtube\.com.*(\.css$|\.js$|\.ico$|\/ytmweb\/_\/js\/|\/ytmweb\/_\/ss\/)/,
    ik = /^https:\/\/[\w-]*\.?youtube\.com.*(purge_shell=1|\/signin|\/logout)/;
var ok = class {
    constructor() {
        var a = gk,
            b = new lk;
        this.h = self;
        this.i = a;
        this.m = b;
        this.M = Vh
    }
    init() {
        this.h.oninstall = this.o.bind(this);
        this.h.onactivate = this.j.bind(this);
        this.h.onfetch = this.l.bind(this);
        this.h.onmessage = this.C.bind(this)
    }
    o(a) {
        this.h.skipWaiting();
        const b = Tj(this.i).catch(c => {
            Oi(c);
            return Promise.resolve()
        });
        a.waitUntil(b)
    }
    j(a) {
        const b = [this.h.clients.claim()];
        this.h.registration.navigationPreload && b.push(this.h.registration.navigationPreload.enable());
        a.waitUntil(Promise.all(b))
    }
    l(a) {
        const b = this;
        return r(function*() {
            var c = b.m,
                d = !!b.h.registration.navigationPreload;
            const e = a.request;
            if (c.o.test(e.url)) vi.h && (delete vi.h.h, t.__SAPISID = void 0, J("VISITOR_DATA", void 0), J("SESSION_INDEX", void 0), J("DELEGATED_SESSION_ID", void 0)), d = a.respondWith, c = c.h, vj(c.h, c.i), Ij(), c = Zj(a), d.call(a, c);
            else if (c.m.test(e.url)) a.respondWith(Xj(c,
                a));
            else if ("navigate" === e.mode) {
                if (L("sw_nav_request_network_first")) {
                    var f = new URL(e.url);
                    f = c.j.test(f.pathname)
                } else f = !1;
                f ? a.respondWith(ak(c, a)) : ek(c, e.url) ? a.respondWith(fk(c, a)) : d && a.respondWith(Zj(a))
            }
        })
    }
    C(a) {
        const b = a.data;
        this.M.includes(b.type) ? Si(a) : "refresh_shell" === b.type && Pj(this.i).catch(c => {
            Oi(c)
        })
    }
};
var pk = class {
    static s() {
        let a = v("ytglobal.storage_");
        a || (a = new pk, w("ytglobal.storage_", a));
        return a
    }
    estimate() {
        return r(function*() {
            const a = navigator;
            let b;
            if (null == (b = a.storage) ? 0 : b.estimate) return a.storage.estimate();
            let c;
            if (null == (c = a.webkitTemporaryStorage) ? 0 : c.queryUsageAndQuota) return qk()
        })
    }
};

function qk() {
    const a = navigator;
    return new Promise((b, c) => {
        let d;
        null != (d = a.webkitTemporaryStorage) && d.queryUsageAndQuota ? a.webkitTemporaryStorage.queryUsageAndQuota((e, f) => {
            b({
                usage: e,
                quota: f
            })
        }, e => {
            c(e)
        }) : c(Error("webkitTemporaryStorage is not supported."))
    })
}
w("ytglobal.storageClass_", pk);

function rk(a, b) {
    pk.s().estimate().then(c => {
        c = Object.assign({}, b, {
            isSw: void 0 === self.document,
            isIframe: self !== self.top,
            deviceStorageUsageMbytes: sk(null == c ? void 0 : c.usage),
            deviceStorageQuotaMbytes: sk(null == c ? void 0 : c.quota)
        });
        a.h("idbQuotaExceeded", c)
    })
}
class tk {
    constructor() {
        var a = uk;
        this.handleError = vk;
        this.h = a;
        this.i = !1;
        void 0 === self.document || self.addEventListener("beforeunload", () => {
            this.i = !0
        });
        this.j = Math.random() <= Rd("ytidb_transaction_ended_event_rate_limit", .02)
    }
    O(a, b) {
        switch (a) {
            case "IDB_DATA_CORRUPTED":
                L("idb_data_corrupted_killswitch") || this.h("idbDataCorrupted", b);
                break;
            case "IDB_UNEXPECTEDLY_CLOSED":
                this.h("idbUnexpectedlyClosed", b);
                break;
            case "IS_SUPPORTED_COMPLETED":
                L("idb_is_supported_completed_killswitch") || this.h("idbIsSupportedCompleted", b);
                break;
            case "QUOTA_EXCEEDED":
                rk(this, b);
                break;
            case "TRANSACTION_ENDED":
                this.j && this.h("idbTransactionEnded", b);
                break;
            case "TRANSACTION_UNEXPECTEDLY_ABORTED":
                a =
                    Object.assign({}, b, {
                        hasWindowUnloaded: this.i
                    }), this.h("idbTransactionAborted", a)
        }
    }
}

function sk(a) {
    return "undefined" === typeof a ? "-1" : String(Math.ceil(a / 1048576))
};
gh(dh(), {
    G: [{
        Ba: /Failed to fetch/,
        weight: 500
    }],
    D: []
});
var {
    handleError: vk = th,
    O: uk = W
} = {
    handleError: function(a) {
        return r(function*() {
            yield Pi();
            uh(a)
        })
    },
    O: function(a, b) {
        return r(function*() {
            yield Pi();
            W(a, b)
        })
    }
};
for (df = new tk; 0 < cf.length;) {
    const a = cf.shift();
    switch (a.type) {
        case "ERROR":
            df.handleError(a.payload);
            break;
        case "EVENT":
            df.O(a.eventType, a.payload)
    }
}
vi.h = new vi;
self.onnotificationclick = function(a) {
    a.notification.close();
    const b = a.notification.data;
    b.isDismissed = !1;
    const c = self.clients.matchAll({
        type: "window",
        includeUncontrolled: !0
    });
    c.then(d => {
        a: {
            var e = b.nav;
            for (const f of d)
                if (f.url === e) {
                    f.focus();
                    break a
                }
            self.clients.openWindow(e)
        }
    });
    a.waitUntil(c);
    a.waitUntil(Zi(b.clickEndpoint))
};
self.onnotificationclose = function(a) {
    a = a.notification.data;
    if (null == a ? 0 : a.parentElement) {
        a.isDismissed && (null == a ? 0 : a.dismissalElement) && qi(gi(), a.dismissalElement);
        var b = Th.s(),
            c = a.parentElement,
            d = Ph(0, c);
        a = c.visualElement ? c.visualElement : d;
        var e = b.l.has(a);
        const f = b.i.get(a);
        b.l.add(a);
        b.i.set(a, !1);
        !1 !== f && (d || c.visualElement) && (!(a = Qh(b, c)) || !Rh(c) && c.data && c.data.loggingDirectives || (d = c.visualElement ? c.visualElement : new Sg({
            trackingParams: d
        }), Rh(c) & 8 ? Nh(b.h, a, d) : Rh(c) & 2 && !e && (b = b.h, c = {
            cttAuthInfo: Zg(a),
            A: a
        }, L("il_via_jspb") ? (e = new rd, e.B(a), d = d.getAsJspb(), C(e, 2, d), B(e, 4, 2), "UNDEFINED_CSN" == a ? Y("visualElementHidden", e, c) : Bh(e, c, b)) : (d = {
            csn: a,
            ve: d.getAsJson(),
            eventType: 2
        }, "UNDEFINED_CSN" == a ? Y("visualElementHidden", d, c) : b ? O("visualElementHidden", d, b, c) : W("visualElementHidden", d, c)))))
    }
};
self.onpush = function(a) {
    a.waitUntil(Zh("NotificationsDisabled").then(b => {
        if (b) return Promise.resolve();
        if (a.data && a.data.text().length) try {
            return Xi(a.data.json())
        } catch (c) {
            return Promise.resolve(c.message)
        }
        return Promise.resolve()
    }));
    a.waitUntil(Vi())
};
self.onpushsubscriptionchange = function() {
    Ti()
};
const gk = new Wj;
(new ok).init();